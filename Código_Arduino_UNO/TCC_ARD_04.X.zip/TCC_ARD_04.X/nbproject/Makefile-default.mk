#
# Generated Makefile - do not edit!
#
# Edit the Makefile in the project folder instead (../Makefile). Each target
# has a -pre and a -post target defined where you can add customized code.
#
# This makefile implements configuration specific macros and targets.


# Include project Makefile
ifeq "${IGNORE_LOCAL}" "TRUE"
# do not include local makefile. User is passing all local related variables already
else
include Makefile
# Include makefile containing local settings
ifeq "$(wildcard nbproject/Makefile-local-default.mk)" "nbproject/Makefile-local-default.mk"
include nbproject/Makefile-local-default.mk
endif
endif

# Environment
MKDIR=gnumkdir -p
RM=rm -f 
MV=mv 
CP=cp 

# Macros
CND_CONF=default
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
IMAGE_TYPE=debug
OUTPUT_SUFFIX=elf
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
else
IMAGE_TYPE=production
OUTPUT_SUFFIX=hex
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
endif

ifeq ($(COMPARE_BUILD), true)
COMPARISON_BUILD=-mafrlcsj
else
COMPARISON_BUILD=
endif

# Object Directory
OBJECTDIR=build/${CND_CONF}/${IMAGE_TYPE}

# Distribution Directory
DISTDIR=dist/${CND_CONF}/${IMAGE_TYPE}

# Source Files Quoted if spaced
SOURCEFILES_QUOTED_IF_SPACED=common/config.c common/timer.c drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c drivers/i2c.c drivers/RS232.c mruv/mruv.c mruv/mruv_test.c mruv/mruv_modes.c main_loop.c

# Object Files Quoted if spaced
OBJECTFILES_QUOTED_IF_SPACED=${OBJECTDIR}/common/config.o ${OBJECTDIR}/common/timer.o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o ${OBJECTDIR}/drivers/i2c.o ${OBJECTDIR}/drivers/RS232.o ${OBJECTDIR}/mruv/mruv.o ${OBJECTDIR}/mruv/mruv_test.o ${OBJECTDIR}/mruv/mruv_modes.o ${OBJECTDIR}/main_loop.o
POSSIBLE_DEPFILES=${OBJECTDIR}/common/config.o.d ${OBJECTDIR}/common/timer.o.d ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d ${OBJECTDIR}/drivers/i2c.o.d ${OBJECTDIR}/drivers/RS232.o.d ${OBJECTDIR}/mruv/mruv.o.d ${OBJECTDIR}/mruv/mruv_test.o.d ${OBJECTDIR}/mruv/mruv_modes.o.d ${OBJECTDIR}/main_loop.o.d

# Object Files
OBJECTFILES=${OBJECTDIR}/common/config.o ${OBJECTDIR}/common/timer.o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o ${OBJECTDIR}/drivers/i2c.o ${OBJECTDIR}/drivers/RS232.o ${OBJECTDIR}/mruv/mruv.o ${OBJECTDIR}/mruv/mruv_test.o ${OBJECTDIR}/mruv/mruv_modes.o ${OBJECTDIR}/main_loop.o

# Source Files
SOURCEFILES=common/config.c common/timer.c drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c drivers/i2c.c drivers/RS232.c mruv/mruv.c mruv/mruv_test.c mruv/mruv_modes.c main_loop.c



CFLAGS=
ASFLAGS=
LDLIBSOPTIONS=

############# Tool locations ##########################################
# If you copy a project from one host to another, the path where the  #
# compiler is installed may be different.                             #
# If you open this project with MPLAB X in the new host, this         #
# makefile will be regenerated and the paths will be corrected.       #
#######################################################################
# fixDeps replaces a bunch of sed/cat/printf statements that slow down the build
FIXDEPS=fixDeps

.build-conf:  ${BUILD_SUBPROJECTS}
ifneq ($(INFORMATION_MESSAGE), )
	@echo $(INFORMATION_MESSAGE)
endif
	${MAKE}  -f nbproject/Makefile-default.mk ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}

MP_PROCESSOR_OPTION=ATmega328P
# ------------------------------------------------------------------------------------
# Rules for buildStep: compile
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${OBJECTDIR}/common/config.o: common/config.c  .generated_files/flags/default/774de9409de7f961b1f3922753e17938f6603f36 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/common" 
	@${RM} ${OBJECTDIR}/common/config.o.d 
	@${RM} ${OBJECTDIR}/common/config.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/common/config.o.d" -MT "${OBJECTDIR}/common/config.o.d" -MT ${OBJECTDIR}/common/config.o -o ${OBJECTDIR}/common/config.o common/config.c 
	
${OBJECTDIR}/common/timer.o: common/timer.c  .generated_files/flags/default/9f39ea07adfaf7c62823fcaa1d3488dccc541141 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/common" 
	@${RM} ${OBJECTDIR}/common/timer.o.d 
	@${RM} ${OBJECTDIR}/common/timer.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/common/timer.o.d" -MT "${OBJECTDIR}/common/timer.o.d" -MT ${OBJECTDIR}/common/timer.o -o ${OBJECTDIR}/common/timer.o common/timer.c 
	
${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o: drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c  .generated_files/flags/default/2c06f3147758ab23f00d2c9627820a63b0cac9f .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core" 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d" -MT "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d" -MT ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o -o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c 
	
${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o: drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c  .generated_files/flags/default/9dd53c1e5b0797518ed92435119e7720ecb9cec .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform" 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d" -MT "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d" -MT ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o -o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c 
	
${OBJECTDIR}/drivers/i2c.o: drivers/i2c.c  .generated_files/flags/default/d7074f88817d3aef99a0818cd625316cdb0e1dbe .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers" 
	@${RM} ${OBJECTDIR}/drivers/i2c.o.d 
	@${RM} ${OBJECTDIR}/drivers/i2c.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/i2c.o.d" -MT "${OBJECTDIR}/drivers/i2c.o.d" -MT ${OBJECTDIR}/drivers/i2c.o -o ${OBJECTDIR}/drivers/i2c.o drivers/i2c.c 
	
${OBJECTDIR}/drivers/RS232.o: drivers/RS232.c  .generated_files/flags/default/fb3fe91fcd2592b1526b45a1cd12c31143f86952 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers" 
	@${RM} ${OBJECTDIR}/drivers/RS232.o.d 
	@${RM} ${OBJECTDIR}/drivers/RS232.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/RS232.o.d" -MT "${OBJECTDIR}/drivers/RS232.o.d" -MT ${OBJECTDIR}/drivers/RS232.o -o ${OBJECTDIR}/drivers/RS232.o drivers/RS232.c 
	
${OBJECTDIR}/mruv/mruv.o: mruv/mruv.c  .generated_files/flags/default/e4d00957db2c62a79c9302a2c0a516064eaedc95 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv.o.d" -MT "${OBJECTDIR}/mruv/mruv.o.d" -MT ${OBJECTDIR}/mruv/mruv.o -o ${OBJECTDIR}/mruv/mruv.o mruv/mruv.c 
	
${OBJECTDIR}/mruv/mruv_test.o: mruv/mruv_test.c  .generated_files/flags/default/da379079487770975cbc588a4934290874312c39 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv_test.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv_test.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv_test.o.d" -MT "${OBJECTDIR}/mruv/mruv_test.o.d" -MT ${OBJECTDIR}/mruv/mruv_test.o -o ${OBJECTDIR}/mruv/mruv_test.o mruv/mruv_test.c 
	
${OBJECTDIR}/mruv/mruv_modes.o: mruv/mruv_modes.c  .generated_files/flags/default/8b061305e9e0db091c671d587033843b0c741471 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv_modes.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv_modes.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv_modes.o.d" -MT "${OBJECTDIR}/mruv/mruv_modes.o.d" -MT ${OBJECTDIR}/mruv/mruv_modes.o -o ${OBJECTDIR}/mruv/mruv_modes.o mruv/mruv_modes.c 
	
${OBJECTDIR}/main_loop.o: main_loop.c  .generated_files/flags/default/2b9e5d301267f4ff420e61e7a975418357758489 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/main_loop.o.d 
	@${RM} ${OBJECTDIR}/main_loop.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -D__DEBUG=1 -g -DDEBUG  -gdwarf-2  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/main_loop.o.d" -MT "${OBJECTDIR}/main_loop.o.d" -MT ${OBJECTDIR}/main_loop.o -o ${OBJECTDIR}/main_loop.o main_loop.c 
	
else
${OBJECTDIR}/common/config.o: common/config.c  .generated_files/flags/default/2f5d052c08325373f202f74618ca982061f411c5 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/common" 
	@${RM} ${OBJECTDIR}/common/config.o.d 
	@${RM} ${OBJECTDIR}/common/config.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/common/config.o.d" -MT "${OBJECTDIR}/common/config.o.d" -MT ${OBJECTDIR}/common/config.o -o ${OBJECTDIR}/common/config.o common/config.c 
	
${OBJECTDIR}/common/timer.o: common/timer.c  .generated_files/flags/default/d7d44f088b02302f14af0b7f0c652d24d4da6d53 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/common" 
	@${RM} ${OBJECTDIR}/common/timer.o.d 
	@${RM} ${OBJECTDIR}/common/timer.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/common/timer.o.d" -MT "${OBJECTDIR}/common/timer.o.d" -MT ${OBJECTDIR}/common/timer.o -o ${OBJECTDIR}/common/timer.o common/timer.c 
	
${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o: drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c  .generated_files/flags/default/2d4e60484f9de236a2c80a7dccefe49742ecd136 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core" 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d" -MT "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o.d" -MT ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o -o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.o drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.c 
	
${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o: drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c  .generated_files/flags/default/922230b88b2ae6395dc0b406a72963e66381d4b7 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform" 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d 
	@${RM} ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d" -MT "${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o.d" -MT ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o -o ${OBJECTDIR}/drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.o drivers/STSW-IMG009_v3.5.5/API/platform/vl53l1_platform.c 
	
${OBJECTDIR}/drivers/i2c.o: drivers/i2c.c  .generated_files/flags/default/aef3ee28d7f1b9743ac8cabd05033a0c020dd77b .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers" 
	@${RM} ${OBJECTDIR}/drivers/i2c.o.d 
	@${RM} ${OBJECTDIR}/drivers/i2c.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/i2c.o.d" -MT "${OBJECTDIR}/drivers/i2c.o.d" -MT ${OBJECTDIR}/drivers/i2c.o -o ${OBJECTDIR}/drivers/i2c.o drivers/i2c.c 
	
${OBJECTDIR}/drivers/RS232.o: drivers/RS232.c  .generated_files/flags/default/befb48b7ab1061e1193a25714d8ebdbcccb147ba .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/drivers" 
	@${RM} ${OBJECTDIR}/drivers/RS232.o.d 
	@${RM} ${OBJECTDIR}/drivers/RS232.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/drivers/RS232.o.d" -MT "${OBJECTDIR}/drivers/RS232.o.d" -MT ${OBJECTDIR}/drivers/RS232.o -o ${OBJECTDIR}/drivers/RS232.o drivers/RS232.c 
	
${OBJECTDIR}/mruv/mruv.o: mruv/mruv.c  .generated_files/flags/default/8b33a1bdb384270e2f28505552565de3372a3fd6 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv.o.d" -MT "${OBJECTDIR}/mruv/mruv.o.d" -MT ${OBJECTDIR}/mruv/mruv.o -o ${OBJECTDIR}/mruv/mruv.o mruv/mruv.c 
	
${OBJECTDIR}/mruv/mruv_test.o: mruv/mruv_test.c  .generated_files/flags/default/99bf0e54d917dbba4c9e5461080ead078828a140 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv_test.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv_test.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv_test.o.d" -MT "${OBJECTDIR}/mruv/mruv_test.o.d" -MT ${OBJECTDIR}/mruv/mruv_test.o -o ${OBJECTDIR}/mruv/mruv_test.o mruv/mruv_test.c 
	
${OBJECTDIR}/mruv/mruv_modes.o: mruv/mruv_modes.c  .generated_files/flags/default/9607dffd65b8675584314936db5fd65b177b0139 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/mruv" 
	@${RM} ${OBJECTDIR}/mruv/mruv_modes.o.d 
	@${RM} ${OBJECTDIR}/mruv/mruv_modes.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/mruv/mruv_modes.o.d" -MT "${OBJECTDIR}/mruv/mruv_modes.o.d" -MT ${OBJECTDIR}/mruv/mruv_modes.o -o ${OBJECTDIR}/mruv/mruv_modes.o mruv/mruv_modes.c 
	
${OBJECTDIR}/main_loop.o: main_loop.c  .generated_files/flags/default/1e911d024a898c95d82127aaea5f06b9ce93b600 .generated_files/flags/default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/main_loop.o.d 
	@${RM} ${OBJECTDIR}/main_loop.o 
	${MP_CC} $(MP_EXTRA_CC_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -c  -x c -D__$(MP_PROCESSOR_OPTION)__   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -DXPRJ_default=$(CND_CONF)  $(COMPARISON_BUILD)  -gdwarf-3 -mno-const-data-in-progmem     -MD -MP -MF "${OBJECTDIR}/main_loop.o.d" -MT "${OBJECTDIR}/main_loop.o.d" -MT ${OBJECTDIR}/main_loop.o -o ${OBJECTDIR}/main_loop.o main_loop.c 
	
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assemble
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assembleWithPreprocess
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: link
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk    
	@${MKDIR} ${DISTDIR} 
	${MP_CC} $(MP_EXTRA_LD_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -Wl,-Map=${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.map  -D__DEBUG=1  -DXPRJ_default=$(CND_CONF)  -Wl,--defsym=__MPLAB_BUILD=1   -mdfp="${DFP_DIR}/xc8"   -gdwarf-2 -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -gdwarf-3 -mno-const-data-in-progmem     $(COMPARISON_BUILD) -Wl,--memorysummary,${DISTDIR}/memoryfile.xml -o ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX}  -o ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}  ${OBJECTFILES_QUOTED_IF_SPACED}      -Wl,--start-group  -Wl,-lm -Wl,--end-group  -Wl,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1
	@${RM} ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.hex 
	
	
else
${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk   
	@${MKDIR} ${DISTDIR} 
	${MP_CC} $(MP_EXTRA_LD_PRE) -mcpu=$(MP_PROCESSOR_OPTION) -Wl,-Map=${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.map  -DXPRJ_default=$(CND_CONF)  -Wl,--defsym=__MPLAB_BUILD=1   -mdfp="${DFP_DIR}/xc8"  -Wl,--gc-sections -O1 -ffunction-sections -fdata-sections -fshort-enums -fno-common -funsigned-char -funsigned-bitfields -I"drivers/STSW-IMG009_v3.5.5/API/core" -I"drivers/STSW-IMG009_v3.5.5/API/platform" -Wall -gdwarf-3 -mno-const-data-in-progmem     $(COMPARISON_BUILD) -Wl,--memorysummary,${DISTDIR}/memoryfile.xml -o ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX}  -o ${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX}  ${OBJECTFILES_QUOTED_IF_SPACED}      -Wl,--start-group  -Wl,-lm -Wl,--end-group 
	${MP_CC_DIR}\\avr-objcopy -O ihex "${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX}" "${DISTDIR}/TCC_ARD_04.X.${IMAGE_TYPE}.hex"
	
endif


# Subprojects
.build-subprojects:


# Subprojects
.clean-subprojects:

# Clean Targets
.clean-conf: ${CLEAN_SUBPROJECTS}
	${RM} -r ${OBJECTDIR}
	${RM} -r ${DISTDIR}

# Enable dependency checking
.dep.inc: .depcheck-impl

DEPFILES=$(wildcard ${POSSIBLE_DEPFILES})
ifneq (${DEPFILES},)
include ${DEPFILES}
endif

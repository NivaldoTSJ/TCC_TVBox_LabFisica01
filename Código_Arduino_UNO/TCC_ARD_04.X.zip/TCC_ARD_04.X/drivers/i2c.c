/*******************************************************************************
 * File:   i2c.c
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: Added TWI status validation, error handling and configurable pull-ups
 *
 ******************************************************************************/

#include "../common/config.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <stddef.h>
#include "i2c.h"

// Timeout limit (~20 ms of delay, plus software processing time)
#define I2C_TIMEOUT_LOOPS 20000U

// Store the last I2C communication error
static uint8_t i2c_last_error = I2C_OK;

//******************************************************************************
// Register the last I2C communication error
//******************************************************************************
//******************************************************************************
// Register the last I2C communication error
//******************************************************************************
static uint8_t I2C_Fail(uint8_t error) {
    i2c_last_error = error;

    // Recover TWI hardware after timeout or bus error
    if(error == I2C_ERROR_TIMEOUT || error == I2C_ERROR_BUS) {
        TWCR = 0U;
        TWCR = (1U << TWEN);
    }

    return error;
}

//******************************************************************************
// Wait for TWINT flag with timeout (supports clock stretching)
//******************************************************************************
static uint8_t I2C_WaitForTWINT(void) {
    uint16_t timeout = I2C_TIMEOUT_LOOPS;

    // TWCR -> Wait for completion of the current TWI operation
    while (!(TWCR & (1U << TWINT))) {
        if (timeout-- == 0U)
            return I2C_Fail(I2C_ERROR_TIMEOUT);

        _delay_us(1);
    }

    return I2C_OK; // Success
}

//******************************************************************************
// Initialize the TWI hardware in master mode
//******************************************************************************
uint8_t I2C_Init(uint32_t clock_freq) {
    uint32_t divider;
    uint32_t twbr_value;

    // Check requested SCL frequency (maximum 400 kHz for VL53L1X)
    if (clock_freq == 0UL || clock_freq > 400000UL)
        return I2C_Fail(I2C_ERROR_PARAMETER);

    // TWBR calculation with prescaler = 1
    divider = ((uint32_t)F_CPU / clock_freq);
    if (divider < 16UL)
        return I2C_Fail(I2C_ERROR_PARAMETER);

    twbr_value = (divider - 16UL) / 2UL;
    if (twbr_value < 10UL || twbr_value > 255UL)
        return I2C_Fail(I2C_ERROR_PARAMETER);

    // Set SDA (PC4) and SCL (PC5) as inputs; preserve other PORTC pins
    DDRC &= (uint8_t)~((1U << DDC4) | (1U << DDC5));

    // Configure internal pull-ups without changing XSHUT (PC0 and PC1)
#if I2C_ENABLE_INTERNAL_PULLUPS
    PORTC |= (uint8_t)((1U << PORTC4) | (1U << PORTC5));
#else
    PORTC &= (uint8_t)~((1U << PORTC4) | (1U << PORTC5));
#endif

    // TWCR - Disable TWI hardware during configuration
    TWCR = 0U;

    // TWSR - TWI Status Register (Prescaler = 1)
    TWSR = 0U;

    // TWBR - TWI Bit Rate Register (72 for 100 kHz at F_CPU = 16 MHz)
    TWBR = (uint8_t)twbr_value;

    // TWCR - Enable TWI hardware
    TWCR = (1U << TWEN);

    i2c_last_error = I2C_OK;
    return I2C_OK; // Success
}

//******************************************************************************
// Send START or REPEATED START condition
//******************************************************************************
uint8_t I2C_Start(void) {
    uint8_t status;

    i2c_last_error = I2C_OK;

    // TWCR -> Send START condition
    TWCR = (1U << TWINT) | (1U << TWSTA) | (1U << TWEN);

    // Wait for TWINT flag (START transmitted)
    if (I2C_WaitForTWINT() != I2C_OK)
        return i2c_last_error;

    // Check status (0x08 = START, 0x10 = REPEATED START)
    status = I2C_GetStatus();
    if (status != 0x08U && status != 0x10U)
        return I2C_Fail(I2C_ERROR_BUS);

    return I2C_OK; // Success
}

//******************************************************************************
// Send STOP condition and wait for bus release
//******************************************************************************
uint8_t I2C_Stop(void) {
    uint16_t timeout = I2C_TIMEOUT_LOOPS;

    // TWCR -> Send STOP condition
    TWCR = (1U << TWINT) | (1U << TWSTO) | (1U << TWEN);

    // Wait for hardware to clear TWSTO
    while (TWCR & (1U << TWSTO)) {
        if (timeout-- == 0U)
            return I2C_Fail(I2C_ERROR_TIMEOUT);

        _delay_us(1);
    }

    return I2C_OK; // Success
}

//******************************************************************************
// Write an address or data byte and verify ACK
//******************************************************************************
uint8_t I2C_Write(uint8_t data) {
    uint8_t status;

    // TWDR -> Load data register
    TWDR = data;

    // TWCR -> Clear TWINT to start transmission
    TWCR = (1U << TWINT) | (1U << TWEN);

    // Wait for data transmission (allows VL53L1X clock stretching)
    if (I2C_WaitForTWINT() != I2C_OK)
        return i2c_last_error;

    // Status check (0x18 = SLA+W ACK, 0x28 = DATA ACK, 0x40 = SLA+R ACK)
    status = I2C_GetStatus();
    if (status == 0x18U || status == 0x28U || status == 0x40U)
        return I2C_OK; // Success

    // Status check (0x20 = SLA+W NACK, 0x30 = DATA NACK, 0x48 = SLA+R NACK)
    if (status == 0x20U || status == 0x30U || status == 0x48U)
        return I2C_Fail(I2C_ERROR_NACK);

    return I2C_Fail(I2C_ERROR_BUS); // Unexpected TWI status
}

//******************************************************************************
// Read one byte and send ACK (intermediate byte)
//******************************************************************************
uint8_t I2C_ReadACK(uint8_t *data) {
    if (data == NULL)
        return I2C_Fail(I2C_ERROR_PARAMETER);

    // TWCR -> Read byte and send ACK
    TWCR = (1U << TWINT) | (1U << TWEN) | (1U << TWEA);

    // Wait for data reception
    if (I2C_WaitForTWINT() != I2C_OK)
        return i2c_last_error;

    // Check status (0x50 = DATA received, ACK transmitted)
    if (I2C_GetStatus() != 0x50U)
        return I2C_Fail(I2C_ERROR_BUS);

    // TWDR -> Return received data byte through pointer
    *data = TWDR;
    return I2C_OK; // Success
}

//******************************************************************************
// Read last byte and send NACK (end of reception)
//******************************************************************************
uint8_t I2C_ReadNACK(uint8_t *data) {
    if (data == NULL)
        return I2C_Fail(I2C_ERROR_PARAMETER);

    // TWCR -> Read byte and send NACK
    TWCR = (1U << TWINT) | (1U << TWEN);

    // Wait for data reception
    if (I2C_WaitForTWINT() != I2C_OK)
        return i2c_last_error;

    // Check status (0x58 = DATA received, NACK transmitted)
    if (I2C_GetStatus() != 0x58U)
        return I2C_Fail(I2C_ERROR_BUS);

    // TWDR -> Return received data byte through pointer
    *data = TWDR;
    return I2C_OK; // Success
}

//******************************************************************************
// Read current TWI status code
//******************************************************************************
uint8_t I2C_GetStatus(void) {
    // Return status register with prescaler bits masked
    return (uint8_t)(TWSR & 0xF8U);
}

//******************************************************************************
// Read last recorded I2C error
//******************************************************************************
uint8_t I2C_GetLastError(void) {
    return i2c_last_error;
}
//******************************************************************************
//******************************************************************************
// Library to RS223 developed under ATmega328P data sheet
// Developed by Nivaldo T. Schiefler Jr.  DSc.
// Build under XC8 compiler
// 02/12/2021 
// Updates: 09/10/26
// 
//******************************************************************************

#include "../common/functions.h"
#include "../common/config.h"
#include <xc.h>
#include <avr/io.h>
#include "RS232.h"

//******************************************************************************
void init_RS232(unsigned char mode_type, const long int BAUD)
{
  //       Asynchronous normal mode (U2Xn = 0)
  unsigned char UBRRn;
  //*******************************************
  //     configure pins to atmega 328
  //*******************************************
  //  clear_pin(PORTD,0);    //RX
  //  set_pin(PORTD,1);      //TX 
  //******************************************* 
  //      Asynchronous normal mode  U2Xn = 0
  //******************************************* 
  //    UBRRn - UBRRnH   UBRRnL          
  //*******************************************          
  if(mode_type == 0)
   {
        UBRRn = (unsigned int)(F_CPU /(16UL*BAUD) - 1);
        UBRR0H = (unsigned char)(UBRRn >> 8);
        UBRR0L = (unsigned char)UBRRn;
        //*******************************************************
        //   UCSRnB ? USART Control and Status Register n B
        //   RXCIEn TXCIEn UDRIEn RXENn TXENn UCSZn2 RXB8n TXB8n
        //*******************************************************
        UCSR0B  = (1 << RXEN0);  // Receiver Enable n
        UCSR0B  = UCSR0B | (1 << TXEN0);  // ransmitter Enable n
        //*******************************************************
        //     UCSRnC ? USART Control and Status Register n C
        //  UMSELn1 UMSELn0 UPMn1 UPMn0 USBSn UCSZn1 UCSZn0 UCPOLn UCSRnC
        //*******************************************************
        //   Table 19-7. UCSZn Bits Settings  page 161
        //   USBSn UCSZn1 UCSZn0  Character Size
        //     0     1      1        8-bit
        UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
        //UCSR0C = UCSR0C | (1 << USBS0);
  }
}  
//******************************************************************************
void write_char_USART(char data)
{
    //  UCSRnA ? USART Control and Status Register n A
    //  Bit 5 ? UDREn: USART Data Register Empty
   while(!(UCSR0A & (1 << UDRE0)));
   // wait of tx buffer to become empty
   //  If UDREn is one, the buffer is empty
               
  // UDRn -> USART I/O Data Register n
   UDR0 = data;
}
//******************************************************************************
void write_text_USART(char *text)
{
  int i;
  for(i = 0; text[i]!= '\0' ; i++)
      write_char_USART(text[i]);  
  write_char_USART('\r');
  write_char_USART('\n');
}
//******************************************************************************
char read_USART(void)
{
    // Bit 7 -> RXCn: USART Receive Complete
    // This flag bit is set when the entire frame in the transmit shift register has been shifted out
     while(!(UCSR0A & (1 << RXC0)));  
     return UDR0;  
}
//******************************************************************************
void read_text_USART(char *read_text)
{
  unsigned int i = 0;
  char flag = 1;
  while(flag)
  {
     read_text[i] = read_USART();   
     if(read_text[i] == '\r')
         flag = 0;
     i++;
  }   
}
//******************************************************************************
char TX_empty_USART(void)
{
   return(UDRE0);  
}
//******************************************************************************
char data_Ready_USART(void)
{
   return  RXC0;
}
//******************************************************************************

void waitCommand(char *buffer, unsigned int maxSize) {
    unsigned int i = 0;
    char flag = 1;
    char c;

    while (flag && (i < maxSize - 1)) 
    {
        c = read_USART();
        if (c == '\r' || c == '\n') {
            if (i > 0)
                flag = 0; // Encerra o laco quando encontra o final do comando
        }
        else {
            buffer[i] = c;
            i++;
        }
    }
    buffer[i] = '\0';
}
//******************************************************************************
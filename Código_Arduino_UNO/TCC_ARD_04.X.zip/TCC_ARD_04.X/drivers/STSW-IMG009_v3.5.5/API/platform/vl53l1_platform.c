/*******************************************************************************
 * File:   vl53l1_platform.c
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: Added I2C read error checking and communication status propagation
 *
 ******************************************************************************/

#include "../../../../common/config.h"
#include "../../../i2c.h"
#include <util/delay.h>
#include "vl53l1_platform.h"

// ST API uses 8-bit device addresses: 0x52 = write, 0x53 = read (7-bit = 0x29)
// Platform routines return 0 on success and -1 on communication failure

//******************************************************************************
// Send START, device address and 16-bit register address (MSB first)
//******************************************************************************
static int8_t VL53L1_SelectRegister(uint16_t dev, uint16_t index) {
    // Device address must contain an even 8-bit write address
    if (dev > 0xFEU || (dev & 0x01U) != 0U)
        return -1;

    if (I2C_Start() != I2C_OK)
        return -1;

    // Slave address (Write mode, R/W = 0)
    if (I2C_Write((uint8_t)dev) != I2C_OK)
        return -1;

    // Send 16-bit register address (MSB first, then LSB)
    if (I2C_Write((uint8_t)(index >> 8)) != I2C_OK)
        return -1;

    if (I2C_Write((uint8_t)(index & 0xFFU)) != I2C_OK)
        return -1;

    return 0; // Success
}

//******************************************************************************
// Switch to read mode using REPEATED START
//******************************************************************************
static int8_t VL53L1_BeginRead(uint16_t dev, uint16_t index) {
    // Select target register before changing bus direction
    if (VL53L1_SelectRegister(dev, index) != 0)
        return -1;

    // Send REPEATED START condition
    if (I2C_Start() != I2C_OK)
        return -1;

    // Slave address (Read mode, R/W = 1)
    if (I2C_Write((uint8_t)(dev | 0x01U)) != I2C_OK)
        return -1;

    return 0; // Success
}

//******************************************************************************
// Write multiple bytes to continuous 16-bit register addresses
//******************************************************************************
int8_t VL53L1_WriteMulti(uint16_t dev, uint16_t index, uint8_t *pdata, uint32_t count) {
    uint32_t i;

    if (count == 0UL)
        return 0;

    if (pdata == NULL)
        return -1;

    // START + slave write address + 16-bit register address
    if (VL53L1_SelectRegister(dev, index) != 0)
        goto fail;

    // Sequential byte transmission
    for (i = 0; i < count; i++) {
        if (I2C_Write(pdata[i]) != I2C_OK)
            goto fail;
    }

    // Send STOP and check whether the bus was released
    return (I2C_Stop() == I2C_OK) ? 0 : -1;

fail:
    // Attempt to release the bus after a communication failure
    (void)I2C_Stop();
    return -1;
}

//******************************************************************************
// Read multiple bytes from continuous 16-bit register addresses
//******************************************************************************
int8_t VL53L1_ReadMulti(uint16_t dev, uint16_t index, uint8_t *pdata, uint32_t count) {
    uint32_t i;
    uint8_t received;
    uint8_t status;

    if (count == 0UL)
        return 0;

    if (pdata == NULL)
        return -1;

    // START + register selection + REPEATED START + slave read address
    if (VL53L1_BeginRead(dev, index) != 0)
        goto fail;

    // ACK for intermediate bytes; NACK for final byte
    for (i = 0; i < count; i++) {
        if (i == (count - 1UL)) {
            status = I2C_ReadNACK(&received); // Last byte requires NACK
        } else {
            status = I2C_ReadACK(&received);  // Intermediate bytes require ACK
        }

        // Stop reading immediately if the hardware reports an error
        if (status != I2C_OK)
            goto fail;

        pdata[i] = received;
    }

    // Send STOP and check whether the bus was released
    return (I2C_Stop() == I2C_OK) ? 0 : -1;

fail:
    // Attempt to release the bus after a communication failure
    (void)I2C_Stop();
    return -1;
}

//******************************************************************************
// Write 8-bit to 16-bit register address
//******************************************************************************
int8_t VL53L1_WrByte(uint16_t dev, uint16_t index, uint8_t data) {
    return VL53L1_WriteMulti(dev, index, &data, 1UL);
}

//******************************************************************************
// Read 8-bit from 16-bit register address
//******************************************************************************
int8_t VL53L1_RdByte(uint16_t dev, uint16_t index, uint8_t *pdata) {
    return VL53L1_ReadMulti(dev, index, pdata, 1UL);
}

//******************************************************************************
// Write 16-bit Word
//******************************************************************************
int8_t VL53L1_WrWord(uint16_t dev, uint16_t index, uint16_t data) {
    uint8_t buffer[2];

    buffer[0] = (uint8_t)(data >> 8);       // MSB
    buffer[1] = (uint8_t)(data & 0xFFU);    // LSB

    return VL53L1_WriteMulti(dev, index, buffer, 2UL);
}

//******************************************************************************
// Write 32-bit Double Word
//******************************************************************************
int8_t VL53L1_WrDWord(uint16_t dev, uint16_t index, uint32_t data) {
    uint8_t buffer[4];

    buffer[0] = (uint8_t)(data >> 24);          // MSB
    buffer[1] = (uint8_t)((data >> 16) & 0xFFU);
    buffer[2] = (uint8_t)((data >> 8) & 0xFFU);
    buffer[3] = (uint8_t)(data & 0xFFU);        // LSB

    return VL53L1_WriteMulti(dev, index, buffer, 4UL);
}

//******************************************************************************
// Read 16-bit Word (Reconstruct)
//******************************************************************************
int8_t VL53L1_RdWord(uint16_t dev, uint16_t index, uint16_t *pdata) {
    uint8_t buffer[2];

    if (pdata == NULL)
        return -1;

    // Read two bytes and verify communication status
    if (VL53L1_ReadMulti(dev, index, buffer, 2UL) != 0)
        return -1;

    // Reconstruct 16-bit value (MSB first)
    *pdata = ((uint16_t)buffer[0] << 8) | (uint16_t)buffer[1];
    return 0; // Success
}

//******************************************************************************
// Read 32-bit Word (Reconstruct)
//******************************************************************************
int8_t VL53L1_RdDWord(uint16_t dev, uint16_t index, uint32_t *pdata) {
    uint8_t buffer[4];

    if (pdata == NULL)
        return -1;

    // Read four bytes and verify communication status
    if (VL53L1_ReadMulti(dev, index, buffer, 4UL) != 0)
        return -1;

    // Reconstruct 32-bit value (MSB first)
    *pdata = ((uint32_t)buffer[0] << 24) |
             ((uint32_t)buffer[1] << 16) |
             ((uint32_t)buffer[2] << 8) |
             (uint32_t)buffer[3];

    return 0; // Success
}

//******************************************************************************
// Delay in milliseconds
//******************************************************************************
int8_t VL53L1_WaitMs(uint16_t dev, int32_t wait_ms) {
    (void)dev; // Device address is not required for this function

    while (wait_ms > 0) {
        _delay_ms(1);
        wait_ms--;
    }

    return 0; // Success
}
//******************************************************************************
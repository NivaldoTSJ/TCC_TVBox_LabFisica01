/******************************************************************************* 
 * File:   vl53l1_platform.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#ifndef VL53L1_PLATFORM_H
#define VL53L1_PLATFORM_H

#include "vl53l1_types.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct {
    uint32_t dummy;
} VL53L1_Dev_t;

typedef VL53L1_Dev_t *VL53L1_DEV;

/** @brief VL53L1_WriteMulti() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_WriteMulti(
        uint16_t      dev,
        uint16_t      index,
        uint8_t      *pdata,
        uint32_t      count);

/** @brief VL53L1_ReadMulti() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_ReadMulti(
        uint16_t      dev,
        uint16_t      index,
        uint8_t      *pdata,
        uint32_t      count);

/** @brief VL53L1_WrByte() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_WrByte(
        uint16_t      dev,
        uint16_t      index,
        uint8_t       data);

/** @brief VL53L1_WrWord() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_WrWord(
        uint16_t      dev,
        uint16_t      index,
        uint16_t      data);

/** @brief VL53L1_WrDWord() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_WrDWord(
        uint16_t      dev,
        uint16_t      index,
        uint32_t      data);

/** @brief VL53L1_RdByte() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_RdByte(
        uint16_t      dev,
        uint16_t      index,
        uint8_t      *pdata);

/** @brief VL53L1_RdWord() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_RdWord(
        uint16_t      dev,
        uint16_t      index,
        uint16_t     *pdata);

/** @brief VL53L1_RdDWord() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_RdDWord(
        uint16_t      dev,
        uint16_t      index,
        uint32_t     *pdata);

/** @brief VL53L1_WaitMs() definition.\n
 * To be implemented by the developer
 */
int8_t VL53L1_WaitMs(
        uint16_t      dev,
        int32_t       wait_ms);

#ifdef __cplusplus
}
#endif

#endif /* VL53L1_PLATFORM_H */
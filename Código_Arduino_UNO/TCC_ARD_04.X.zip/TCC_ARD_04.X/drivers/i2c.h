/*******************************************************************************
 * File:   i2c.h
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: Added I2C error codes, read status and configurable pull-ups
 *
 ******************************************************************************/

#ifndef I2C_H
#define I2C_H

#include <stdint.h>

//******************************************************************************
// Codigos de retorno (0 - sucesso, diferente de 0 - falha)
#define I2C_OK               0U
#define I2C_ERROR_TIMEOUT    1U
#define I2C_ERROR_NACK       2U
#define I2C_ERROR_BUS        3U
#define I2C_ERROR_PARAMETER  4U

//******************************************************************************
// Habilita pull-ups internos em SDA (PC4) e SCL (PC5)
#ifndef I2C_ENABLE_INTERNAL_PULLUPS
#define I2C_ENABLE_INTERNAL_PULLUPS 1
#endif

//******************************************************************************
// Inicializa o barramento I2C (retorna I2C_OK em caso de sucesso)
uint8_t I2C_Init(uint32_t clock_freq);

//******************************************************************************
// Inicia a comunicacao ou gera REPEATED START
uint8_t I2C_Start(void);

//******************************************************************************
// Finaliza a comunicacao e aguarda a liberacao do barramento
uint8_t I2C_Stop(void);

//******************************************************************************
// Envia um byte e verifica se o dispositivo respondeu com ACK
uint8_t I2C_Write(uint8_t data);

//******************************************************************************
// Le um byte, envia ACK e retorna o dado por ponteiro
uint8_t I2C_ReadACK(uint8_t *data);

//******************************************************************************
// Le o ultimo byte, envia NACK e retorna o dado por ponteiro
uint8_t I2C_ReadNACK(uint8_t *data);

//******************************************************************************
// Retorna o estado atual do controlador TWI (bits de prescaler ignorados)
uint8_t I2C_GetStatus(void);

//******************************************************************************
// Retorna o ultimo erro identificado pela biblioteca I2C
uint8_t I2C_GetLastError(void);

#endif /* I2C_H */
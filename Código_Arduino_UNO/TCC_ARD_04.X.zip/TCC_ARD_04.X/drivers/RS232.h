//******************************************************************************
// Library to RS223 developed under ATmega328P data sheet
// Developed by Nivaldo T. Schiefler Jr.  DSc.
// Build under XC8 compiler
// 02/12/2021 
// Updates: 21/08/26 
// 
//******************************************************************************
/*
  void init_RS232(unsigned char mode_type, const long int BAUD);
  void write_char_USART(char data);
  void write_text_USART(char *text);
  char read_USART(void);
  void read_text_USART(char *read_text);
  char TX_empty_USART(void);
  char data_Ready_USART(void);
  void waitCommand(char *buffer, unsigned int maxSize);
 */
//******************************************************************************

#ifndef RS232_H
#define	RS232_H

#ifdef	__cplusplus
extern "C" {
#endif
//******************************************************************************
  void init_RS232(unsigned char mode_type, const long int BAUD);
  void write_char_USART(char data);
  void write_text_USART(char *text);
  char read_USART(void);
  void read_text_USART(char *read_text);
  char TX_empty_USART(void);
  char data_Ready_USART(void);
  void waitCommand(char *buffer, unsigned int maxSize);
//******************************************************************************
#ifdef	__cplusplus
}
#endif

#endif	/* RS232_H */


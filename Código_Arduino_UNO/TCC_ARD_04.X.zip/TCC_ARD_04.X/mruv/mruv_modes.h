/******************************************************************************* 
 * File:   mruv_modes.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#ifndef MRUV_MODES_H
#define MRUV_MODES_H

// Modo de Sincroniza��o
void sincronizeMode(void);

// Modo de Calibra��o
void offsetMode(void);

// Modo de Experimento
void experimentMode(void);

#endif /* MRUV_MODES_H */
/******************************************************************************* 
 * File:   mruv_test.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#ifndef MRUV_TEST_H
#define MRUV_TEST_H

// Simula��o do modo experimento
void testExperimentMode(void);

// Simula��o do modo de calibra��o
void testOffsetMode(void);

#endif /* MRUV_TEST_H */
/******************************************************************************* 
 * File:   mruv.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#ifndef MRUV_H
#define MRUV_H

// Configura��es iniciais
void mruv_setup(void);

// Loop principal
void mruv_run(void);

#endif /* MRUV_H */
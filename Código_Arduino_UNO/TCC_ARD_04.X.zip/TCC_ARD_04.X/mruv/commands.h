/*
 ******************************************************************************** 
 * File:   commands.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 09 de Outubro de 2026
 * Updates: 
 * Arquivo guia para c�digos de comunica��o dos perif�ricos do aparato experimental
 ********************************************************************************

PROTOCOLO (FORMATO: XX_XXXX)

Categoria:
  - MD : Sele��o de Modo            (PC -> Arduino)
  - PG : Pings                      (PC -> Arduino)
  - ST : In�cio de Rotina           (PC -> Arduino)
  - RS : Resposta de Status         (Arduino -> PC)
  - EN : Fim de Rotina              (Arduino -> PC)

Modos:
  "MD_SINC"  <-  "sincroMode"  (Sincroniza��o e teste inicial)
  "MD_OFST"  <-  "offsetMode"  (Calibra��o de offset dos sensores)
  "MD_EXPT"  <-  "expertMode"  (Execu��o do experimento real)
  "MD_TXPT"  <-  "testXpMode"  (Simula��o do modo experimento)
  "MD_TOFS"  <-  "testOsMode"  (Simula��o do modo offset)

Pings:
  "PG_MCUP"  <-  "AR_PING"      (Teste de conex�o do Microcontrolador)
  "PG_SNS1"  <-  "S1_PING"      (Teste de resposta do Sensor 1)
  "PG_SNS2"  <-  "S2_PING"      (Teste de resposta do Sensor 2)

In�cio de Rotina:
  "ST_OFST"  <-  "ST_OS"        (Inicia amostragem para calibra��o)
  "ST_EXPT"  <-  "ST_XP"        (Inicia captura continua do MRUV)

Resposta de Status:
  "RS_MCUK"  <-  "OK_AR"        (Microcontrolador OK)
  "RS_MCER"  <-  "ER_AR"        (Erro no Microcontrolador)
  "RS_S1OK"  <-  "OK_S1"        (Sensor 1 Inicializado OK)
  "RS_S1ER"  <-  "ER_S1"        (Erro ao inicializar Sensor 1)
  "RS_S2OK"  <-  "OK_S2"        (Sensor 2 Inicializado OK)
  "RS_S2ER"  <-  "ER_S2"        (Erro ao inicializar Sensor 2)
  "RS_OFOK"  <-  -              (Offsets OK)
  "RS_OFER"  <-  -              (Offsets Erro)

Fim de Rotina:
  "EN_OFST"  <-  "EN_OS"        (Calibra��o de offset finalizada)
  "EN_EXPT"  <-  "EN_XP"        (Experimento MRUV finalizado)

 ********************************************************************************
 */
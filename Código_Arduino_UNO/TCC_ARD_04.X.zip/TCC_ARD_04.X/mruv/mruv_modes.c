/******************************************************************************* 
 * File:   mruv_modes.c  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates:
 *
 ******************************************************************************/

#include "../common/config.h"
#include "../common/functions.h"
#include "../common/timer.h"
#include "../drivers/RS232.h"
#include "../drivers/STSW-IMG009_v3.5.5/API/core/VL53L1X_api.h"
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include "mruv_modes.h"

#define ADDR_DEFAULT 0x52  // Default address (0x29 7-bit)
#define ADDR_SENSOR1 0x54  // Sensor 1 address (0x2A 7-bit)
#define ADDR_SENSOR2 0x52  // Sensor 2 address (0x29 7-bit)

const unsigned int timeBudget = 50; // Measurement budget in ms

//******************************************************************************
// SYNCHRONIZATION MODE
//******************************************************************************
void sincronizeMode(void) {
    char cmd[32];

    unsigned int dev1 = ADDR_DEFAULT;
    unsigned int dev2 = ADDR_DEFAULT;
    unsigned int sensorId = 0;
    unsigned int testDist = 0;
    int t = 0;
    int status = 0;
    int sensorOK = 0;
    unsigned char bootState = 0;
    unsigned char dataReady = 0;

    // RESET BOTH SENSORS
    clear_pin(PORTC, 0);
    clear_pin(PORTC, 1);
    _delay_ms(200);

    // MCU PING
    waitCommand(cmd, sizeof(cmd));
    if(strcmp(cmd, "PG_MCUP") == 0) {
        write_text_USART("RS_MCUK");
    }
    else {
        write_text_USART("RS_MCER");
        return;
    }

    // SENSOR 1 PING
    waitCommand(cmd, sizeof(cmd));
    if(strcmp(cmd, "PG_SNS1") == 0) {

        // Turn on Sensor 1 (PC0) and keep Sensor 2 (PC1) disabled
        clear_pin(PORTC, 1);
        set_pin(PORTC, 0);
        _delay_ms(200);

        dev1 = ADDR_DEFAULT;
        sensorOK = 1;

        // Verify Sensor 1 identification
        sensorId = 0;
        status = VL53L1X_GetSensorId(dev1, &sensorId);
        if(status != 0 || sensorId != 0xEACC) {
            sensorOK = 0;
        }

        // Wait for Sensor 1 boot
        if(sensorOK == 1) {
            bootState = 0;
            status = 0;
            t = 0;

            while(bootState == 0 && status == 0 && t < 100) {
                status = VL53L1X_BootState(dev1, &bootState);
                if(status == 0 && bootState == 0) {
                    _delay_ms(5);
                }
                t++;
            }

            if(status != 0 || bootState == 0) {
                sensorOK = 0;
            }
        }

        // Initialize Sensor 1
        if(sensorOK == 1) {
            status = VL53L1X_SensorInit(dev1);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Change Sensor 1 address from 0x52 to 0x54
        if(sensorOK == 1) {
            status = VL53L1X_SetI2CAddress(dev1, ADDR_SENSOR1);
            if(status == 0) {
                dev1 = ADDR_SENSOR1;
            }
            else {
                sensorOK = 0;
            }
        }

        // Verify Sensor 1 at the new address
        if(sensorOK == 1) {
            sensorId = 0;
            status = VL53L1X_GetSensorId(dev1, &sensorId);
            if(status != 0 || sensorId != 0xEACC) {
                sensorOK = 0;
            }
        }

        // Configure Sensor 1
        if(sensorOK == 1) {
            status = VL53L1X_SetROI(dev1, 16, 8);
            if(status == 0) {
                status = VL53L1X_SetROICenter(dev1, 195);
            }
            if(status == 0) {
                status = VL53L1X_SetDistanceMode(dev1, 1);
            }
            if(status == 0) {
                status = VL53L1X_SetTimingBudgetInMs(dev1, timeBudget);
            }
            if(status == 0) {
                status = VL53L1X_SetInterMeasurementInMs(dev1, timeBudget + 5);
            }
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Start continuous ranging on Sensor 1
        if(sensorOK == 1) {
            status = VL53L1X_StartRanging(dev1);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Wait for the first measurement from Sensor 1
        if(sensorOK == 1) {
            _delay_ms(200);
            dataReady = 0;
            testDist = 0;
            status = 0;
            t = 0;

            while(dataReady == 0 && status == 0 && t < 100) {
                status = VL53L1X_CheckForDataReady(dev1, &dataReady);
                if(status == 0 && dataReady == 0) {
                    _delay_ms(5);
                }
                t++;
            }

            if(status != 0 || dataReady == 0) {
                sensorOK = 0;
            }
        }

        // Read the first distance from Sensor 1
        if(sensorOK == 1) {
            status = VL53L1X_GetDistance(dev1, &testDist);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Clear interrupt and verify the distance
        if(sensorOK == 1) {
            status = VL53L1X_ClearInterrupt(dev1);
            if(status != 0 || testDist == 0) {
                sensorOK = 0;
            }
        }
    }
    else {
        sensorOK = 0;
    }

    // SENSOR 1 RESPONSE
    if(sensorOK == 1) {
        write_text_USART("RS_S1OK");
    }
    else {
        write_text_USART("RS_S1ER");
        clear_pin(PORTC, 0);
    }

    // SENSOR 2 PING
    waitCommand(cmd, sizeof(cmd));
    if(strcmp(cmd, "PG_SNS2") == 0) {

        // Turn on Sensor 2 (PC1) and keep Sensor 1 (PC0) running
        set_pin(PORTC, 1);
        _delay_ms(200);

        dev2 = ADDR_SENSOR2;
        sensorOK = 1;

        // Verify Sensor 2 identification
        sensorId = 0;
        status = VL53L1X_GetSensorId(dev2, &sensorId);
        if(status != 0 || sensorId != 0xEACC) {
            sensorOK = 0;
        }

        // Wait for Sensor 2 boot
        if(sensorOK == 1) {
            bootState = 0;
            status = 0;
            t = 0;

            while(bootState == 0 && status == 0 && t < 100) {
                status = VL53L1X_BootState(dev2, &bootState);
                if(status == 0 && bootState == 0) {
                    _delay_ms(5);
                }
                t++;
            }

            if(status != 0 || bootState == 0) {
                sensorOK = 0;
            }
        }

        // Initialize Sensor 2
        if(sensorOK == 1) {
            status = VL53L1X_SensorInit(dev2);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Sensor 2 keeps the default I2C address (0x52)

        // Configure Sensor 2
        if(sensorOK == 1) {
            status = VL53L1X_SetROI(dev2, 16, 8);
            if(status == 0) {
                status = VL53L1X_SetROICenter(dev2, 195);
            }
            if(status == 0) {
                status = VL53L1X_SetDistanceMode(dev2, 1);
            }
            if(status == 0) {
                status = VL53L1X_SetTimingBudgetInMs(dev2, timeBudget);
            }
            if(status == 0) {
                status = VL53L1X_SetInterMeasurementInMs(dev2, timeBudget + 5);
            }
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Start continuous ranging on Sensor 2
        if(sensorOK == 1) {
            status = VL53L1X_StartRanging(dev2);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Wait for the first measurement from Sensor 2
        if(sensorOK == 1) {
            _delay_ms(200);
            dataReady = 0;
            testDist = 0;
            status = 0;
            t = 0;

            while(dataReady == 0 && status == 0 && t < 100) {
                status = VL53L1X_CheckForDataReady(dev2, &dataReady);
                if(status == 0 && dataReady == 0) {
                    _delay_ms(5);
                }
                t++;
            }

            if(status != 0 || dataReady == 0) {
                sensorOK = 0;
            }
        }

        // Read the first distance from Sensor 2
        if(sensorOK == 1) {
            status = VL53L1X_GetDistance(dev2, &testDist);
            if(status != 0) {
                sensorOK = 0;
            }
        }

        // Clear interrupt and verify the distance
        if(sensorOK == 1) {
            status = VL53L1X_ClearInterrupt(dev2);
            if(status != 0 || testDist == 0) {
                sensorOK = 0;
            }
        }
    }
    else {
        sensorOK = 0;
    }

    // SENSOR 2 RESPONSE
    if(sensorOK == 1) {
        write_text_USART("RS_S2OK");
    }
    else {
        write_text_USART("RS_S2ER");
        clear_pin(PORTC, 1);
    }
}

//******************************************************************************
// CALIBRATION / OFFSET MODE
//******************************************************************************
void offsetMode(void) {
    char cmd[32];
    char bufferString[32];

    unsigned int dev1 = ADDR_SENSOR1;
    unsigned int dev2 = ADDR_SENSOR2;
    unsigned int dev = 0;
    unsigned int dist = 0;

    unsigned char dataReady = 0;
    unsigned char rangeStatus = 255;

    unsigned long sumS1 = 0;
    unsigned long sumS2 = 0;

    int16_t offsetS1 = 0;
    int16_t offsetS2 = 0;
    int16_t previousOffsetS1 = 0;
    int16_t previousOffsetS2 = 0;

    int valid = 0;
    int attempts = 0;
    int sensor = 0;
    int t = 0;
    int status = 0;
    int rangeStatusCode = 0;
    int clearStatus = 0;

    // WAIT FOR CALIBRATION COMMAND
    waitCommand(cmd, sizeof(cmd));

    if(strcmp(cmd, "ST_OFST") != 0) {
        return;
    }

    // SAVE PREVIOUS OFFSETS
    status = VL53L1X_GetOffset(dev1, &previousOffsetS1);

    if(status == 0) {
        status = VL53L1X_GetOffset(dev2, &previousOffsetS2);
    }

    if(status != 0) {
        write_text_USART("EN_OFST");
        return;
    }

    // RESET INTERNAL OFFSETS
    status = VL53L1X_SetOffset(dev1, 0);

    if(status == 0) {
        status = VL53L1X_SetOffset(dev2, 0);
    }

    if(status != 0) {
        goto calibrationError;
    }

    // Wait before starting calibration
    _delay_ms(1000);

    // CALIBRATE BOTH SENSORS
    for(sensor = 1; sensor <= 2; sensor++) {

        dev = (sensor == 1) ? dev1 : dev2;

        valid = 0;
        attempts = 0;

        // Collect 30 valid measurements
        while(valid < 30 && attempts < 90) {

            attempts++;

            // Progress messages keep Qt serial communication active
            if(attempts % 5 == 1) {
                if(sensor == 1) {
                    write_text_USART("OFST_S1");
                }
                else {
                    write_text_USART("OFST_S2");
                }
            }

            dataReady = 0;
            status = 0;
            t = 0;

            // Wait for a new measurement
            while(dataReady == 0 && status == 0 && t < 100) {
                status = VL53L1X_CheckForDataReady(dev, &dataReady);

                if(status == 0 && dataReady == 0) {
                    _delay_ms(5);
                }

                t++;
            }

            // Skip communication errors and timeouts
            if(status != 0 || dataReady == 0) {
                continue;
            }

            // Read distance and measurement status
            dist = 0;
            rangeStatus = 255;

            status = VL53L1X_GetDistance(dev, &dist);

            rangeStatusCode = VL53L1X_GetRangeStatus(
                dev, &rangeStatus
            );

            clearStatus = VL53L1X_ClearInterrupt(dev);

            // Accept only valid measurements
            if(status == 0 &&
               rangeStatusCode == 0 &&
               clearStatus == 0 &&
               rangeStatus == 0 &&
               dist > 0) {

                if(sensor == 1) {
                    sumS1 += dist;
                }
                else {
                    sumS2 += dist;
                }

                valid++;
            }
        }

        // Calibration requires exactly 30 valid measurements
        if(valid != 30) {
            goto calibrationError;
        }

        // Calculate sensor offset
        if(sensor == 1) {
            offsetS1 = 140 - (sumS1 / 30);
        }
        else {
            offsetS2 = 140 - (sumS2 / 30);
        }

        _delay_ms(200);
    }

    // APPLY OFFSETS
    status = VL53L1X_SetOffset(dev1, offsetS1);

    if(status == 0) {
        status = VL53L1X_SetOffset(dev2, offsetS2);
    }

    if(status != 0) {
        goto calibrationError;
    }

    // READ APPLIED OFFSETS
    status = VL53L1X_GetOffset(dev1, &offsetS1);

    if(status == 0) {
        status = VL53L1X_GetOffset(dev2, &offsetS2);
    }

    if(status != 0) {
        goto calibrationError;
    }

    // SEND CALIBRATION RESULTS
    sprintf(bufferString, "T,%d,%d", offsetS1, offsetS2);
    write_text_USART(bufferString);

    write_text_USART("EN_OFST");
    return;

calibrationError:

    // Restore previous offsets if calibration fails
    VL53L1X_SetOffset(dev1, previousOffsetS1);
    VL53L1X_SetOffset(dev2, previousOffsetS2);

    // No T message: Qt will report calibration failure
    write_text_USART("EN_OFST");
}

//******************************************************************************
// EXPERIMENT MODE
//******************************************************************************
void experimentMode(void) {
    char cmd[32];
    char bufferString[32];

    unsigned int dev1 = ADDR_SENSOR1;
    unsigned int dev2 = ADDR_SENSOR2;

    int offsetS1 = 0;
    int offsetS2 = 0;

    const unsigned int movementStarted = 60;
    const unsigned int movementEnded = 60;
    const unsigned int switchDist = 550;

    unsigned int distance = 0;
    unsigned int sampleIndex = 0;
    unsigned long sampleTime = 0;
    unsigned char dataReady = 0;

    int experimentModeStarted = 0;
    int sentInitial = 0;
    int switchSensor = 0;

    int status = 0;
    int clearStatus = 0;
    int t = 0;

    // WAIT FOR OFFSETS
    waitCommand(cmd, sizeof(cmd));

    if(sscanf(cmd, "T,%d,%d", &offsetS1, &offsetS2) != 2) {
        write_text_USART("RS_OFER");
        return;
    }

    // APPLY OFFSETS
    status = VL53L1X_SetOffset(dev1, offsetS1);
    if(status == 0) {
        status = VL53L1X_SetOffset(dev2, offsetS2);
    }
    if(status != 0) {
        write_text_USART("RS_OFER");
        return;
    }
    write_text_USART("RS_OFOK");
    
    // WAIT FOR EXPERIMENT COMMAND
    waitCommand(cmd, sizeof(cmd));

    if(strcmp(cmd, "ST_EXPT") == 0) {
        experimentModeStarted = 1;
    }

    // EXPERIMENT LOOP
    while(experimentModeStarted == 1) {

        // WAIT FOR MOVEMENT TO START
        if(sentInitial == 0) {
            dataReady = 0;
            status = VL53L1X_CheckForDataReady(dev1, &dataReady);

            if(status == 0 && dataReady != 0) {
                sampleTime = millis();
                status = VL53L1X_GetDistance(dev1, &distance);
                clearStatus = VL53L1X_ClearInterrupt(dev1);

                if(status == 0 && clearStatus == 0) {
                    if(distance >= movementStarted) {
                        sentInitial = 1;

                        // Send the first measurement
                        sprintf(bufferString, "T,%u,%d,%lu,%u",
                                sampleIndex, switchSensor,
                                sampleTime, distance);
                        write_text_USART(bufferString);
                    }
                }
            }
        }

        // MOVEMENT IN PROGRESS
        else {

            // SENSOR 1 MEASUREMENTS
            if(switchSensor == 0) {
                dataReady = 0;
                status = VL53L1X_CheckForDataReady(dev1, &dataReady);

                if(status == 0 && dataReady != 0) {
                    sampleTime = millis();
                    status = VL53L1X_GetDistance(dev1, &distance);
                    clearStatus = VL53L1X_ClearInterrupt(dev1);

                    if(status == 0 && clearStatus == 0) {
                        sampleIndex++;

                        // Send Sensor 1 measurement
                        sprintf(bufferString, "T,%u,%d,%lu,%u",
                                sampleIndex, switchSensor,
                                sampleTime, distance);
                        write_text_USART(bufferString);

                        // Switch to Sensor 2
                        if(distance >= switchDist) {
                            switchSensor = 1;
                        }
                    }
                }
            }

            // SENSOR 2 MEASUREMENTS
            else {
                dataReady = 0;
                status = VL53L1X_CheckForDataReady(dev2, &dataReady);

                if(status == 0 && dataReady != 0) {
                    sampleTime = millis();
                    status = VL53L1X_GetDistance(dev2, &distance);
                    clearStatus = VL53L1X_ClearInterrupt(dev2);

                    if(status == 0 && clearStatus == 0) {
                        sampleIndex++;

                        // Send Sensor 2 measurement
                        sprintf(bufferString, "T,%u,%d,%lu,%u",
                                sampleIndex, switchSensor,
                                sampleTime, distance);
                        write_text_USART(bufferString);

                        // CHECK END OF MOVEMENT
                        if(distance <= movementEnded) {

                            // Wait for one additional measurement
                            dataReady = 0;
                            status = 0;
                            t = 0;

                            while(dataReady == 0 && status == 0 && t < 250) {
                                status = VL53L1X_CheckForDataReady(dev2, &dataReady);

                                if(status == 0 && dataReady == 0) {
                                    _delay_ms(2);
                                }
                                t++;
                            }

                            // Send the final measurement
                            if(status == 0 && dataReady != 0) {
                                sampleTime = millis();
                                status = VL53L1X_GetDistance(dev2, &distance);
                                clearStatus = VL53L1X_ClearInterrupt(dev2);

                                if(status == 0 && clearStatus == 0) {
                                    sampleIndex++;

                                    sprintf(bufferString, "T,%u,%d,%lu,%u",
                                            sampleIndex, switchSensor,
                                            sampleTime, distance);
                                    write_text_USART(bufferString);
                                }
                            }

                            // Finish experiment
                            write_text_USART("EN_EXPT");
                            experimentModeStarted = 0;
                        }
                    }
                }
            }
        }

        // Short pause between I2C checks
        _delay_ms(2);
    }
}
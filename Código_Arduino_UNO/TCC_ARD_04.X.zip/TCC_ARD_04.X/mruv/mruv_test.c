/******************************************************************************* 
 * File:   mruv_test.c  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates:
 *
 ******************************************************************************/

#include "../common/config.h"
#include "../common/timer.h"
#include "../drivers/RS232.h"
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "mruv_test.h"

void testExperimentMode(void) {
    char cmd[32];
    char bufferString[32];
    unsigned char experimentModeStarted = 0;
    int offsetS1 = 0;
    int offsetS2 = 0;

    // Recebe os offsets, mas nao os aplica aos dados simulados.
    waitCommand(cmd, sizeof(cmd));
    if (sscanf(cmd, "T,%d,%d", &offsetS1, &offsetS2) != 2) {
        return;
    }
    write_text_USART("RS_OFOK");

    // Aguarda o comando que inicia o experimento.
    waitCommand(cmd, sizeof(cmd));
    if (strcmp(cmd, "ST_EXPT") == 0) {
        experimentModeStarted = 1;
    }

    unsigned int distance = 0;
    unsigned int sampleIndex = 0;
    const unsigned int movementEnded = 50;  // mm
    const unsigned int switchDist = 600;    // mm
    unsigned char switchSensor = 0;

    const float accel = 0.3;                // m/s�

    _delay_ms(2000);

    while (experimentModeStarted) {
        float t = sampleIndex * 0.055;      // tempo decorrido

        if (!switchSensor) {
            distance = ((0.5 * (accel * 1000.0) * t * t) + (rand() % 7) + 7);
            sampleIndex++;

            sprintf(bufferString, "T,%u,%u,%lu,%u",
                    sampleIndex, switchSensor, millis(), distance);
            write_text_USART(bufferString);

            if (distance >= switchDist) {
                switchSensor = 1;
            }
        }
        else {
            distance = (1200 - ((0.5 * (accel * 1000.0) * t * t) + (rand() % 7) + 7));
            sampleIndex++;

            sprintf(bufferString, "T,%u,%u,%lu,%u",
                    sampleIndex, switchSensor, millis(), distance);
            write_text_USART(bufferString);

            if (distance <= movementEnded) {
                write_text_USART("EN_EXPT");
                experimentModeStarted = 0;
            }
        }

        _delay_ms(55); // 55 ms time step
    }
}

//******************************************************************************
// TEST OFFSET / CALIBRATION MODE
//******************************************************************************
void testOffsetMode(void) {
    char cmd[32];
    char bufferString[32];

    waitCommand(cmd, sizeof(cmd));
    if (strcmp(cmd, "ST_OFST") == 0) {
        int offsetS1 = 0;
        int offsetS2 = 0;
        long sumS1 = 0;
        long sumS2 = 0;
        int i = 0;

        _delay_ms(1000);

        // 30 samples Sensor 1
        for (i = 0; i < 30; i++) {
            sumS1 += 140 + (rand() % 7) + 7;
        }
        offsetS1 = (int)((sumS1 / 30) - 140);

        _delay_ms(200);

        // 30 samples Sensor 2
        for (i = 0; i < 30; i++) {
            sumS2 += 140 + (rand() % 7) + 9;
        }
        offsetS2 = (int)((sumS2 / 30) - 140);

        _delay_ms(200);

        sprintf(bufferString, "T,%d,%d", offsetS1, offsetS2);
        write_text_USART(bufferString);
        write_text_USART("EN_OFST");
    }
}
//******************************************************************************
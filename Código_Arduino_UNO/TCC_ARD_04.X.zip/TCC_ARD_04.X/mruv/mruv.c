/******************************************************************************* 
 * File:   mruv.c  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates:
 *
 ******************************************************************************/

#include "../common/config.h"
#include "../common/functions.h"
#include "../common/timer.h"
#include "../drivers/RS232.h"
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include "mruv.h"
#include "mruv_modes.h"
#include "mruv_test.h"

//******************************************************************************
// MRUV Module Initialization
//******************************************************************************
void mruv_setup(void) {
    // Sensors disabled (PC1 = S1, PC0 = S2)
    clear_pin(PORTC, 1);
    clear_pin(PORTC, 0);
    _delay_ms(200);

    // Initialize Timer
    timer0_init();
}

//******************************************************************************
// Main Execution Loop & Command Parser
//******************************************************************************
void mruv_run(void) {
    char cmd[32];

    while (1) {
        // Wait for command
        waitCommand(cmd, sizeof(cmd));

        if      (strcmp(cmd, "MD_SINC") == 0) {
            sincronizeMode();
        } 
        else if (strcmp(cmd, "MD_OFST") == 0) {
            offsetMode();
        } 
        else if (strcmp(cmd, "MD_EXPT") == 0) {
            experimentMode();
        }
        else if (strcmp(cmd, "MD_TXPT") == 0) {
            testExperimentMode();
        }
        else if (strcmp(cmd, "MD_TOFS") == 0) {
            testOffsetMode();
        }
    }
}
//******************************************************************************
/******************************************************************************* 
 * File:   main_loop.c  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 09 de Outubro de 2026
 * Updates:
 *
 ******************************************************************************/

#include "common/config.h"
#include "drivers/i2c.h"
#include "drivers/RS232.h"
#include "mruv/mruv.h"

//******************************************************************************
// Main execution
//******************************************************************************
int main(void) {
    // Hardware baseline initialization
    setup();                    // config.c
    I2C_Init(100000);           // I2C - 100 kHz
    init_RS232(0, 9600);        // Serial

    // MRUV setup and execution
    mruv_setup();
    mruv_run();

    return 0;
}
//******************************************************************************
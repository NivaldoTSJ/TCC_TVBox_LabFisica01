/******************************************************************************* 
 * File:   timer.h  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#ifndef TIMER_H
#define TIMER_H

// Timer0 do ATmega328P
void timer0_init(void);

// Retorna o tempo decorrido em milissegundos
unsigned long millis(void);

#endif /* TIMER_H */
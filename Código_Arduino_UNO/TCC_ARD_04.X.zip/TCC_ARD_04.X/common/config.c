/******************************************************************************* 
 * File:   config.c  
 * Developed by Nivaldo T. Schiefler Jr.  DSc.
 * Build under XC8 compiler
 * Created on 1 de Janeiro de 2021
 * Updates: 
 *
 ******************************************************************************/

#include <avr/io.h>
#include "config.h"

void setup(void) {
    //*************************************************************************
    //    DDRx       The Port B Data Direction Register
    //               0  input      1  output
    //*************************************************************************
    DDRB = 0b00000000; // digital PORT
    PORTB = 0; // The Port B Data Register
    //*************************************************************************
    DDRC = 0b00000011; // analog/digital PORT
    PORTC = 0; // The Port C Data Register
    //*************************************************************************
    DDRD = 0b00000010; // digital PORT
    PORTD = 0; // The Port D Data Register
    //*************************************************************************

}
//*****************************************************************************
/******************************************************************************* 
 * File:   timer.c  
 * Developed by Pedro H. Deluca
 * Build under XC8 compiler
 * Created on 08 de Outubro de 2026
 * Updates: 
 *
 ******************************************************************************/

#include "config.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include "timer.h"

// Milliseconds counter variable
static volatile unsigned long timer0_millis = 0;

//******************************************************************************
// Timer0 Compare Match A Interrupt Service Routine (1 ms)
//******************************************************************************
ISR(TIMER0_COMPA_vect) {
    timer0_millis++;
}

//******************************************************************************
void timer0_init(void) {
    // TCCR0A -> Set CTC (Clear Timer on Compare) Mode
    TCCR0A = (1 << WGM01);

    // OCR0A -> Compare value: (16 MHz / (64 * 1000 Hz)) - 1 = 249 (1 ms)
    OCR0A = 249;

    // TIMSK0 -> Enable Output Compare A Match Interrupt
    TIMSK0 = (1 << OCIE0A);

    // TCCR0B -> Set Prescaler to 64
    TCCR0B = (1 << CS01) | (1 << CS00);

    // Enable global interrupts
    sei();
}

//******************************************************************************
unsigned long millis(void) {
    unsigned long m;
    char sreg = SREG;

    // Disable interrupts for the reading of 32-bit variable
    cli();
    m = timer0_millis;
    SREG = sreg;

    return m;
}
//******************************************************************************
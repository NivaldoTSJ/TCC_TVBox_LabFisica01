#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QThread>
#include <QCoreApplication>

//=====================================================================
//  LEITURA DE DADOS SERIAIS
//=====================================================================
void MainWindow::readSerialData()
{
    while(arduino -> canReadLine())
    {
        QString signal = QString::fromUtf8(arduino -> readLine()).trimmed();

        if(signal.startsWith("T,"))
        {
            QStringList signalBits = signal.split(',');
            if(signalBits.size() == 5)                              // Recebeu o dado inteiro
            {
                double timeBrute     = signalBits[3].toDouble();    // Tempo
                double distanceBrute = signalBits[4].toDouble();    // Distância

                if(timeZero == 0) {
                    timeZero = timeBrute;                           // Tempo inicial
                    dataSpeed.append(0);                            // Inclui os primeiros pontos nos outros vetores
                    dataAcceleration.append(0);
                }
                double timeFinal = timeBrute - timeZero;            // Tempo relativo em segundos
                timeFinal = timeFinal / 1000;

                double distanceFinal = 0;
                if ((signalBits[2].toInt()) == 0) {                 // Sensor 1
                    distanceFinal = distanceBrute + 132;            // 124 de comprimento do carrinho + 8 de distância entre a borda do trilho e o sensor
                    distanceFinal = distanceFinal / 1000;
                }
                else {                                              // Sensor 2
                    distanceFinal = 1190 - (distanceBrute);         // 1200 de comprimento total do trilho - 10 de distância entre a borda do trilho e o sensor
                    distanceFinal = distanceFinal / 1000;
                }

                if(distanceFinal > 0) {
                    dataTime.append(timeFinal);                     // Adiciona aos vetores
                    dataPosition.append(distanceFinal);

                    dataBrute -> append(timeFinal, distanceFinal);  // Adiciona aos dados
                }

                if(timeFinal > (eixoX -> max())) {
                    eixoX -> setMax(timeFinal + 0.2);               // Se o espaço no gráfico for insuficiente, adiciona mais espaço
                    zeroLineSeries -> replace(1, eixoX -> max(), 0.0);
                }
            }
        }
        else if(signal == "EN_EXPT") {
            disconnect(arduino, &QSerialPort::readyRead, this, &MainWindow::readSerialData);
            arduino -> clear();

            // Velocidades e Acelerações Discretas
            for(int i = 1; i < dataTime.size(); i++) {
                double speedTemp = (dataPosition[i] - dataPosition[i - 1]) / (dataTime[i] - dataTime[i - 1]);
                dataSpeed.append(speedTemp);

                double accelTemp = (dataSpeed[i] - dataSpeed[i - 1]) / (dataTime[i] - dataTime[i - 1]);
                dataAcceleration.append(accelTemp);
            }

            getFunction();

            // Calcula a média móvel
            calculateMovingAverage();

            // Preenche a curva filtrada de posição
            dataFiltered    -> clear();

            for(int i = 0; i < dataTime.size(); i++) {
                dataFiltered    -> append(dataTime[i], filteredPosition[i]);
            }

            // Libera a visualização do filtro
            ui  -> checkBoxExpAvarage -> setEnabled(true);

            for(int i = 0; i < dataTime.size(); i++) {
                double timeTemp = dataTime[i];
                dataRefined -> append(timeTemp, (A*timeTemp*timeTemp + B*timeTemp + C));
            }

            // Recalcula a simulação com os tempos reais da coleta
            if(!simuPosition.isEmpty()) {
                simuTime.clear();
                simuPosition.clear();
                simuSpeed.clear();
                simuAcceleration.clear();
                dataSimu    -> clear();

                for(int i = 0; i < dataTime.size(); i++) {
                    double t = dataTime[i];

                    simuTime.append(t);
                    simuPosition.append(simuA * t * t + simuB * t + simuC);
                    simuSpeed.append(2.0 * simuA * t + simuB);
                    simuAcceleration.append(2.0 * simuA);

                    dataSimu    -> append(t, simuPosition[i]);
                }
            }

            eixoX   -> setRange(0, dataTime.last());
            zeroLineSeries  -> replace(0, 0.0, 0.0);
            zeroLineSeries  -> replace(1, dataTime.last(), 0.0);

            ui      -> labelExpEquationPosition     -> setText(QString::asprintf("x(t) = %.3f t² + %.3f t + %.3f", A, B, C));
            ui      -> labelExpEquationSpeed        -> setText(QString::asprintf("v(t) = %.3f t + %.3f", (2*A), B));
            ui      -> labelExpEquationAcceleration -> setText(QString::asprintf("a(t) = %.3f", (2*A)));

            ui      -> pushButtonExpBeginGathering          -> setEnabled(true);
            ui      -> pushButtonExpEquationPosition        -> setEnabled(true);
            ui      -> pushButtonExpEquationSpeed           -> setEnabled(true);
            ui      -> pushButtonExpEquationAcceleration    -> setEnabled(true);
            ui      -> pushButtonExpGetTable                -> setEnabled(true);
            ui      -> pushButtonExpSimu                    -> setEnabled(true);
            ui      -> checkBoxExpAvarage                   -> setEnabled(true);
            ui      -> pushButtonAboutUs                    -> setEnabled(true);
            ui      -> pushButtonInstructions               -> setEnabled(true);
            ui      -> checkBoxExpSimu                      -> setEnabled(!simuPosition.isEmpty());

            break;
        }
    }
}
//=====================================================================

//=====================================================================
//  REGRESSÃO QUADRÁTICA
//=====================================================================
void MainWindow::getFunction()
{
    int dataAmountTotal = dataTime.size();

    // Acumuladores
    double S0 = dataAmountTotal;
    double S1 = 0.0;
    double S2 = 0.0;
    double S3 = 0.0;
    double S4 = 0.0;
    double Y0 = 0.0;
    double Y1 = 0.0;
    double Y2 = 0.0;

    // Somatórios
    for(int i = 0; i < dataAmountTotal; i++) {
        double t = dataTime[i];
        double y = dataPosition[i];

        double t2 = t * t;
        double t3 = t2 * t;
        double t4 = t3 * t;

        S1 += t;
        S2 += t2;
        S3 += t3;
        S4 += t4;

        Y0 += y;
        Y1 += t * y;
        Y2 += t2 * y;
    }

    // Determinante Principal
    double D = S4 * (S2 * S0 - S1 * S1) - S3 * (S3 * S0 - S1 * S2) + S2 * (S3 * S1 - S2 * S2);

    // Evita divisão por zero caso os pontos sejam colineares ou insuficientes
    if(std::abs(D) < 1e-15) {
        A = 0.0;
        B = 0.0;
        C = 0.0;
        return;
    }

    // Determinantes auxiliares
    double DA = Y2 * (S2 * S0 - S1 * S1) - S3 * (Y1 * S0 - S1 * Y0) + S2 * (Y1 * S1 - S2 * Y0);
    double DB = S4 * (Y1 * S0 - S1 * Y0) - Y2 * (S3 * S0 - S1 * S2) + S2 * (S3 * Y0 - Y1 * S2);
    double DC = S4 * (S2 * Y0 - Y1 * S1) - S3 * (S3 * Y0 - Y1 * S2) + Y2 * (S3 * S1 - S2 * S2);

    A = DA / D;         // m/s²
    B = DB / D;         // m/s
    C = DC / D;         // m
}
//=====================================================================

//=====================================================================
//  FILTRO DE MÉDIA MÓVEL
//=====================================================================
void MainWindow::calculateMovingAverage()
{
    // Configuração do filtro
    int window = 5;
    bool centered = true;

    // Limpa dados filtrados anteriores
    filteredPosition.clear();
    filteredSpeed.clear();
    filteredAcceleration.clear();

    // Média móvel das posições
    for(int i = 0; i < dataPosition.size(); i++) {
        int start = 0;
        int end = 0;

        if(centered) {
            start = i - window / 2;
            end = i + window / 2;
        }
        else {
            start = i;
            end = i + window - 1;
        }

        // Limita a janela aos pontos disponíveis
        if(start < 0) {
            start = 0;
        }

        if(end >= dataPosition.size()) {
            end = dataPosition.size() - 1;
        }

        double sum = 0.0;

        for(int j = start; j <= end; j++) {
            sum += dataPosition[j];
        }

        filteredPosition.append(sum / (end - start + 1));
    }

    // Velocidades e acelerações filtradas
    filteredSpeed.append(0.0);
    filteredAcceleration.append(0.0);

    for(int i = 1; i < dataTime.size(); i++) {
        double speedTemp = (filteredPosition[i] - filteredPosition[i - 1]) / (dataTime[i] - dataTime[i - 1]);
        filteredSpeed.append(speedTemp);

        double accelTemp = (filteredSpeed[i] - filteredSpeed[i - 1]) / (dataTime[i] - dataTime[i - 1]);
        filteredAcceleration.append(accelTemp);
    }
}
//=====================================================================

//=====================================================================
//  SALVAR E CARREGAR OFFSETS
//=====================================================================
void MainWindow::saveOffset(int offsetS1temp, int offsetS2temp)
{
    offsetS1 = offsetS1temp;
    offsetS2 = offsetS2temp;

    QString path = QCoreApplication::applicationDirPath() + "/offsets.txt";
    QFile file(path);

    if (file.open(QIODevice::WriteOnly)) {
        file.write(QString::asprintf("%d,%d", offsetS1, offsetS2).toUtf8());
        file.close();
    }
}

void MainWindow::loadOffset()
{
    QString path = QCoreApplication::applicationDirPath() + "/offsets.txt";
    QFile file(path);

    if(!file.exists()) {   // Valor padrão se não estiver calibrado
        offsetS1 = 7;
        offsetS2 = 7;
        saveOffset(offsetS1, offsetS2);

        ui -> labelTextOffsetS1Value    -> setText(QString::asprintf("%d mm", offsetS1));
        ui -> labelTextOffsetS2Value    -> setText(QString::asprintf("%d mm", offsetS2));
        ui -> labelTextOffsetStatus     -> setText("Valor padrão");

        QCoreApplication::processEvents();
        return;
    }

    if(file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        QString fileLine = in.readLine();
        file.close();

        QStringList offsetValues = fileLine.split(',');

        if(offsetValues.size() == 2) {
            offsetS1 = offsetValues[0].toInt();
            offsetS2 = offsetValues[1].toInt();

            ui  -> labelTextOffsetS1Value    -> setText(QString::asprintf("%d mm", offsetS1));
            ui  -> labelTextOffsetS2Value    -> setText(QString::asprintf("%d mm", offsetS2));
            ui  -> labelTextOffsetStatus     -> setText("Última calibração");
        }
        else {
            offsetS1 = 0;
            offsetS2 = 0;

            ui  -> labelTextOffsetS1Value    -> setText("-");
            ui  -> labelTextOffsetS2Value    -> setText("-");
            ui  -> labelTextOffsetStatus     -> setText("Necessário recalibrar");
        }
    }
    else {
        offsetS1 = 0;
        offsetS2 = 0;

        ui  -> labelTextOffsetS1Value    -> setText("-");
        ui  -> labelTextOffsetS2Value    -> setText("-");
        ui  -> labelTextOffsetStatus     -> setText("Necessário recalibrar");
    }
}
//=====================================================================

//=====================================================================
//  SALVAR PLANILHA
//=====================================================================
void MainWindow::exportCSV(const QString &path, bool exportSimu, bool exportFiltered)
{
    QFile file(path);
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return;
    }

    int dataAmountTotal = dataTime.size();

    QString header = "Tempo (s);"
                     "Posicao Discreta (m);Velocidade Discreta (m/s);Aceleracao Discreta (m/s2);"
                     "Posicao Analitica (m);Velocidade Analitica (m/s);Aceleracao Analitica (m/s2);"
                     "Posicao Simulada (m);Velocidade Simulada (m/s);Aceleracao Simulada (m/s2);"
                     "Posicao Filtrada (m);Velocidade Filtrada (m/s);Aceleracao Filtrada (m/s2)\n";
    file.write(header.toUtf8());

    int Idx = 0;
    double TimRe = dataTime[Idx];
    double PosRe = dataPosition[Idx];
    double PosAn = A * TimRe * TimRe + B * TimRe + C;
    double SpdRe = dataSpeed[Idx];
    double SpdAn = 2 * A * TimRe + B;
    double AclRe = dataAcceleration[Idx];
    double AclAn = 2 * A;

    QString line = QString::asprintf("%.3f;%.3f;%.3f;%.3f;%.3f;%.3f;%.3f", TimRe, PosRe, SpdRe, AclRe, PosAn, SpdAn, AclAn);

    if(exportSimu) {
        line += QString::asprintf(";%.3f;%.3f;%.3f", simuPosition[Idx], simuSpeed[Idx], simuAcceleration[Idx]);
    }
    else {
        line += ";-;-;-";
    }
    if(exportFiltered) {
        line += QString::asprintf(";%.3f;%.3f;%.3f\n",
                                  filteredPosition[Idx], filteredSpeed[Idx], filteredAcceleration[Idx]);
    }
    else {
        line += ";-;-;-\n";
    }
    file.write(line.replace('.', ',').toUtf8());

    if(dataPercentage > 1) {
        int step = qRound(100.0 / dataPercentage);
        if(step < 1) {
            step = 1;
        }

        for(Idx = step; Idx < (dataAmountTotal - 1); Idx += step) {
            TimRe = dataTime[Idx];
            PosRe = dataPosition[Idx];
            PosAn = A * TimRe * TimRe + B * TimRe + C;
            SpdRe = dataSpeed[Idx];
            SpdAn = 2 * A * TimRe + B;
            AclRe = dataAcceleration[Idx];
            AclAn = 2 * A;

            line = QString::asprintf("%.3f;%.3f;%.3f;%.3f;%.3f;%.3f;%.3f", TimRe, PosRe, SpdRe, AclRe, PosAn, SpdAn, AclAn);

            if(exportSimu) {
                line += QString::asprintf(";%.3f;%.3f;%.3f", simuPosition[Idx], simuSpeed[Idx], simuAcceleration[Idx]);
            }
            else {
                line += ";-;-;-";
            }
            if(exportFiltered) {
                line += QString::asprintf(";%.3f;%.3f;%.3f\n",
                                          filteredPosition[Idx], filteredSpeed[Idx], filteredAcceleration[Idx]);
            }
            else {
                line += ";-;-;-\n";
            }
            file.write(line.replace('.', ',').toUtf8());
        }
    }

    Idx     = dataAmountTotal - 1;
    TimRe   = dataTime[Idx];
    PosRe   = dataPosition[Idx];
    PosAn   = A * TimRe * TimRe + B * TimRe + C;
    SpdRe   = dataSpeed[Idx];
    SpdAn   = 2 * A * TimRe + B;
    AclRe   = dataAcceleration[Idx];
    AclAn   = 2 * A;

    line = QString::asprintf("%.3f;%.3f;%.3f;%.3f;%.3f;%.3f;%.3f", TimRe, PosRe, SpdRe, AclRe, PosAn, SpdAn, AclAn);

    if(exportSimu) {
        line += QString::asprintf(";%.3f;%.3f;%.3f", simuPosition[Idx], simuSpeed[Idx], simuAcceleration[Idx]);
    }
    else {
        line += ";-;-;-";
    }
    if(exportFiltered) {
        line += QString::asprintf(";%.3f;%.3f;%.3f\n",
                                  filteredPosition[Idx], filteredSpeed[Idx], filteredAcceleration[Idx]);
    }
    else {
        line += ";-;-;-\n";
    }
    file.write(line.replace('.', ',').toUtf8());

    file.close();
}
//=====================================================================

//=====================================================================
//  ATUALIZAR GRÁFICO
//=====================================================================
void MainWindow::updateGraph(int mode)
{
    // Limpa os dados anteriores do gráfico
    dataBrute       -> clear();
    dataRefined     -> clear();
    dataSimu        -> clear();
    dataFiltered    -> clear();

    // Seleciona os vetores conforme o gráfico escolhido
    const QVector<double> *realValues       = &dataPosition;
    const QVector<double> *simuValues       = &simuPosition;
    const QVector<double> *filteredValues   = &filteredPosition;

    if(mode == 1) {
        realValues      = &dataSpeed;
        simuValues      = &simuSpeed;
        filteredValues  = &filteredSpeed;
    }
    else if(mode == 2) {
        realValues      = &dataAcceleration;
        simuValues      = &simuAcceleration;
        filteredValues  = &filteredAcceleration;
    }

    // Limites iniciais do eixo vertical
    double minY = 0.0;
    double maxY = 1.2;

    if(mode != 0) {
        minY = (*realValues)[0];
        maxY = (*realValues)[0];
    }

    // Preenche as séries do gráfico
    for(int i = 0; i < dataTime.size(); i++) {
        double tempTime         = dataTime[i];
        double analyticValue    = A * tempTime * tempTime + B * tempTime + C;

        if(mode == 1) {
            analyticValue = 2 * A * tempTime + B;
        }
        else if(mode == 2) {
            analyticValue = 2 * A;
        }

        dataBrute   -> append(tempTime, (*realValues)[i]);
        dataRefined -> append(tempTime, analyticValue);

        if(!simuTime.isEmpty()) {
            dataSimu -> append(tempTime, (*simuValues)[i]);
        }

        if(!filteredPosition.isEmpty()) {
            dataFiltered -> append(tempTime, (*filteredValues)[i]);
        }

        if(mode != 0) {
            minY = qMin(minY, qMin((*realValues)[i], analyticValue));
            maxY = qMax(maxY, qMax((*realValues)[i], analyticValue));
        }
    }

    // Atualiza os eixos
    eixoX -> setRange(0, dataTime.last());
    eixoY -> setRange(minY, maxY);
}
//=====================================================================

//=====================================================================
//  CÁLCULO DA SIMULAÇÃO
//=====================================================================
void MainWindow::calculateSimulation(int mode, double pulleyMass, double accelerationInput, double speedInput)
{
    // Parâmetros físicos
    double acceleration = 0.0;
    double speed = 0.0;

    pulleyMass += 10;

    // Condições iniciais
    simuA = 0.0;
    simuB = 0.0;
    simuC = 0.203;

    // Cálculo dos coeficientes
    if(mode == 0) {             // MRUV por massa aplicada
        acceleration = (pulleyMass * 9.81) / (283.0 + pulleyMass);
        simuA = acceleration / 2.0;
    }
    else if(mode == 1) {        // MRUV por aceleração
        acceleration = accelerationInput;
        simuA = acceleration / 2.0;
    }
    else if(mode == 2) {        // MRU por força inicial aplicada
        acceleration = (pulleyMass * 9.81) / (283.0 + pulleyMass);
        speed = std::sqrt(2.0 * acceleration * 0.01);
        simuB = speed;
    }
    else if(mode == 3) {        // MRU por velocidade
        speed = speedInput;
        simuB = speed;
    }

    // Limpa os dados anteriores da simulação
    simuTime.clear();
    simuPosition.clear();
    simuSpeed.clear();
    simuAcceleration.clear();
    dataSimu    -> clear();

    if(!dataTime.isEmpty()) {
        // Simulação com os tempos reais da coleta
        for(int i = 0; i < dataTime.size(); i++) {
            double t = dataTime[i];

            simuTime.append(t);
            simuPosition.append(simuA * t * t + simuB * t + simuC);
            simuSpeed.append(2 * simuA * t + simuB);
            simuAcceleration.append(2 * simuA);

            dataSimu    -> append(t, simuPosition[i]);
        }
    }
    else {
        // Simulação inicial com intervalos de 55 ms
        double t = 0;
        double position = simuC;

        while((position < 1.2) && (simuA > 0.0 || simuB > 0.0)) {
            position = simuA * t * t + simuB * t + simuC;

            simuTime.append(t);
            simuPosition.append(position);
            simuSpeed.append(2 * simuA * t + simuB);
            simuAcceleration.append(2 * simuA);

            dataSimu    -> append(t, position);

            t += 0.055;
        }
    }
}
//=====================================================================


//=====================================================================
//  INICIAR COLETA DE DADOS
//=====================================================================
bool MainWindow::startExperiment()
{
    arduino     -> write("MD_EXPT\n");
    //arduino   -> write("MD_TXPT\n");
    arduino     -> flush();
    QThread::msleep(200);

    // Limpa dados
    timeZero = 0;

    dataTime.clear();
    dataPosition.clear();
    dataSpeed.clear();
    dataAcceleration.clear();

    filteredPosition.clear();
    filteredSpeed.clear();
    filteredAcceleration.clear();

    dataBrute       -> clear();
    dataRefined     -> clear();
    dataFiltered    -> clear();

    eixoX   -> setRange(0, 2.5);
    eixoY   -> setRange(0, 1.2);

    // Reinicia e limpa conexão serial aos dados
    disconnect(arduino, &QSerialPort::readyRead, this, &MainWindow::readSerialData);
    arduino     -> clear();

    // Carrega offsets salvos
    loadOffset();

    // Envia offsets armazenados
    arduino     -> write(QString::asprintf("T,%d,%d\n", offsetS1, offsetS2).toUtf8());
    arduino     -> flush();

    // Aguarda confirmação dos offsets
    QString ans = "";

    if(arduino -> canReadLine() || arduino -> waitForReadyRead(2000)) {
        while(!arduino -> canReadLine() && arduino -> waitForReadyRead(200)) {
        }

        if(arduino -> canReadLine()) {
            ans = QString::fromUtf8(arduino -> readLine()).trimmed();

            // Inicia coleta se os offsets foram aplicados
            if(ans == "RS_OFOK") {
                connect(arduino, &QSerialPort::readyRead, this, &MainWindow::readSerialData);

                arduino -> write("ST_EXPT\n");
                arduino -> flush();

                return true;
            }
        }
    }

    return false;
}


//=====================================================================
//  SINCRONIZAÇÃO DO ARDUINO
//=====================================================================
bool MainWindow::syncArduino(const QString &portName)
{
    // Reinicia a conexão
    if(arduino  -> isOpen()) {
        arduino -> close();
    }

    // Variáveis de verificação
    bool ARD_OK = false;
    bool S1_OK  = false;
    bool S2_OK  = false;

    // Configura porta
    arduino -> setPortName(portName);
    arduino -> setBaudRate(QSerialPort::Baud9600);
    arduino -> setDataBits(QSerialPort::Data8);
    arduino -> setParity(QSerialPort::NoParity);
    arduino -> setStopBits(QSerialPort::OneStop);
    arduino -> setFlowControl(QSerialPort::NoFlowControl);

    // Abre porta
    if(!arduino -> open(QIODevice::ReadWrite)) {
        ui  -> labelTextSincArdStatus   -> setText("Erro de Inicialização");
        QCoreApplication::processEvents();
        return false;
    }

    // Conecta no arduino
    ui      -> labelTextSincArdStatus   -> setText("Aguardando reinicialização da placa");
    QCoreApplication::processEvents();
    QThread::msleep(2000);
    arduino -> clear();

    // Inicia a sequencia de sincronização e comunicação
    arduino -> write("MD_SINC\n");
    arduino -> flush();
    QThread::msleep(2000);

    // Comando recebido
    QString ans = "";

    // Enviando PING arduino
    ui      -> labelTextSincArdStatus   -> setText("Enviando PING");
    QCoreApplication::processEvents();
    arduino -> write("PG_MCUP\n");
    arduino -> flush();

    // Espera resposta PING arduino
    if(arduino -> waitForReadyRead(2000)) {
        while((!arduino -> canReadLine()) && (arduino -> waitForReadyRead(200))) {
        }
        ans = QString::fromUtf8(arduino -> readLine()).trimmed();
    }
    else {
        ans = "ERRO";
    }

    if(ans != "RS_MCUK") {
        ui  -> labelTextSincArdStatus -> setText("Erro");
        ui  -> labelTextSincS1Status  -> setText("Erro");
        ui  -> labelTextSincS2Status  -> setText("Erro");
        arduino -> close();
        return false;
    }
    else {
        ui  -> labelTextSincArdStatus -> setText("Conectado");
        ARD_OK = true;
    }
    QCoreApplication::processEvents();

    // Enviando PING Sensor 1
    ui  -> labelTextSincS1Status    -> setText("Enviando PING");
    QCoreApplication::processEvents();
    arduino -> write("PG_SNS1\n");
    arduino -> flush();

    // Espera resposta PING Sensor 1
    if(arduino  -> waitForReadyRead(2000)) {
        while((!arduino -> canReadLine()) && (arduino   -> waitForReadyRead(200))) {
        }
        ans = QString::fromUtf8(arduino -> readLine()).trimmed();
    }
    else {
        ans = "ERRO";
    }

    if(ans != "RS_S1OK") {
        ui  -> labelTextSincS1Status    -> setText("Erro");
    }
    else {
        ui  -> labelTextSincS1Status    -> setText("Conectado");
        S1_OK = true;
    }
    QCoreApplication::processEvents();

    // Enviando PING Sensor 2
    ui  -> labelTextSincS2Status -> setText("Enviando PING");
    QCoreApplication::processEvents();
    arduino -> write("PG_SNS2\n");
    arduino -> flush();

    if(arduino -> waitForReadyRead(2000)) {
        while((!arduino -> canReadLine()) && (arduino   -> waitForReadyRead(200))) {
        }
        ans = QString::fromUtf8(arduino -> readLine()).trimmed();
    }
    else {
        ans = "ERRO";
    }

    if(ans != "RS_S2OK") {
        ui  -> labelTextSincS2Status    -> setText("Erro");
    }
    else {
        ui  -> labelTextSincS2Status    -> setText("Conectado");
        S2_OK = true;
    }
    QCoreApplication::processEvents();

    // Verifica o resultado da sincronização
    if(ARD_OK && S1_OK && S2_OK) {
        return true;
    }

    return false;
}

//=====================================================================
//  CALIBRAÇÃO DOS SENSORES
//=====================================================================
bool MainWindow::calibrateSensors()
{
    arduino     -> write("MD_OFST\n");
    //arduino   -> write("MD_TOFS\n");
    arduino     -> flush();
    QThread::msleep(200);

    arduino     -> write("ST_OFST\n");                                    // Envia comando
    arduino     -> flush();

    int tempS1 = 0;
    int tempS2 = 0;
    bool INF_OK = false;
    bool END_OK = false;

    while(arduino   -> waitForReadyRead(8000)) {                      // Tempo máximo de espera
        while(arduino   -> canReadLine()) {                           // Aguarda até receber a linha toda
            QString signal = QString::fromUtf8(arduino  -> readLine()).trimmed();

            if(signal.startsWith("T,")) {
                QStringList signalBits = signal.split(',');
                if(signalBits.size() == 3) {
                    tempS1 = signalBits[1].toInt();
                    tempS2 = signalBits[2].toInt();
                    INF_OK = true;
                }
            }
            else if(signal == "EN_OFST") {                            // Conclui leitura se completa
                END_OK = true;
                break;
            }
        }

        if(END_OK) {                                                // Conclui a espera
            break;
        }
    }

    if(INF_OK && END_OK) {
        saveOffset(tempS1, tempS2);                                 // Salva valores no arquivo
        return true;
    }
    else {
        return false;
    }
}
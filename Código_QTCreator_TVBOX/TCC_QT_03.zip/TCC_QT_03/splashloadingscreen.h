#ifndef SPLASHLOADINGSCREEN_H
#define SPLASHLOADINGSCREEN_H

#include <QDialog>
#include <QMovie>

namespace Ui {
class SplashLoadingScreen;
}

class SplashLoadingScreen : public QDialog
{
    Q_OBJECT

public:
    explicit SplashLoadingScreen(QWidget *parent = nullptr);
    ~SplashLoadingScreen();

private:
    Ui::SplashLoadingScreen *ui;
    QMovie *carMovie;

    void iniciarCarregamento();
};

#endif // SPLASHLOADINGSCREEN_H
#include "mainwindow.h"
#include "splashloadingscreen.h"
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 1. Instancia e executa a tela de carregamento (Splash Screen)
    SplashLoadingScreen splash;

    // 2. Quando a barra chegar a 100% e o diálogo for aceito (accept()), abre a janela principal
    if (splash.exec() == QDialog::Accepted) {
        MainWindow w;
        w.show();
        return QApplication::exec();
    }

    return 0;
}
#include "instructionsscreen.h"
#include "ui_instructionsscreen.h"

instructionsScreen::instructionsScreen(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::instructionsScreen)
{
    ui->setupUi(this);

    setWindowTitle("Instruções");

    setWindowFlags(Qt::Dialog | Qt::WindowCloseButtonHint);

    connect(ui -> pushButtonInstructionsClose, &QPushButton::clicked, this, &QDialog::accept);
}

instructionsScreen::~instructionsScreen()
{
    delete ui;
}

void instructionsScreen::on_pushButtonInstructionsClose_clicked()
{
    close();
}


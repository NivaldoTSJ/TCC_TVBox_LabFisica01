#ifndef ABOUTUSSCREEN_H
#define ABOUTUSSCREEN_H

#include <QDialog>

namespace Ui {
class AboutUsScreen;
}

class AboutUsScreen : public QDialog
{
    Q_OBJECT

public:
    explicit AboutUsScreen(QWidget *parent = nullptr);
    ~AboutUsScreen();

private slots:
    void on_pushButtonAboutClose_clicked();

private:
    Ui::AboutUsScreen *ui;
};

#endif // ABOUTUSSCREEN_H
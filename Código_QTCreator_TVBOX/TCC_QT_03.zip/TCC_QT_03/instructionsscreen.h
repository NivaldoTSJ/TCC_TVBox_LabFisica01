#ifndef INSTRUCTIONSSCREEN_H
#define INSTRUCTIONSSCREEN_H

#include <QDialog>

namespace Ui {
class instructionsScreen;
}

class instructionsScreen : public QDialog
{
    Q_OBJECT

public:
    explicit instructionsScreen(QWidget *parent = nullptr);
    ~instructionsScreen();

private slots:
    void on_pushButtonInstructionsClose_clicked();

private:
    Ui::instructionsScreen *ui;
};

#endif // INSTRUCTIONSSCREEN_H

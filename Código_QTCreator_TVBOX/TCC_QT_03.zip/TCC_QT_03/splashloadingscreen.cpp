#include "splashloadingscreen.h"
#include "ui_splashloadingscreen.h"
#include <QRandomGenerator>
#include <QThread>
#include <QCoreApplication>
#include <QTimer>

SplashLoadingScreen::SplashLoadingScreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SplashLoadingScreen)
{
    ui      -> setupUi(this);

    this    -> setObjectName("SplashLoadingScreen");
    setWindowTitle("Loading");

    setAttribute(Qt::WA_StyledBackground, true);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    // Carrega e inicia a animação do carrinho
    carMovie = new QMovie(":/images/car.gif");
    ui      -> labelGifSplashCar        -> setMovie(carMovie);
    carMovie                        -> start();

    // Configura a barra de progresso
    ui      -> progressBarSplash        -> setRange(0, 100);
    ui      -> progressBarSplash        -> setValue(0);

    // Mensagem inicial de abertura
    ui      -> labelTextSplashStatus    -> setText("Desprezando a resistência do ar...");

    // Inicia o loop de carregamento assim que a janela é exibida
    QTimer::singleShot(500, this, &SplashLoadingScreen::iniciarCarregamento);
}

SplashLoadingScreen::~SplashLoadingScreen()
{
    delete ui;
}

void SplashLoadingScreen::iniciarCarregamento()
{
    // Coordenadas do movimento
    int xInicial = 0;
    int xFinal   = 600;
    int yFixo    = 340;

    for(int i = 0; i <= 100; i++) {
        ui  -> progressBarSplash    -> setValue(i);

        // Carrinho
        int xAtual = xInicial + ((xFinal - xInicial) * i) / 100;
        ui  -> labelGifSplashCar    -> move(xAtual, yFixo);

        // Imagens de Fundo
        if(i == 0) {
            this  -> setStyleSheet("#SplashLoadingScreen { border-image: url(:/images/loading_01.jpeg); }");
        }
        else if(i == 35) {
            this  -> setStyleSheet("#SplashLoadingScreen { border-image: url(:/images/loading_02.jpeg); }");
        }
        else if(i == 70) {
            this  -> setStyleSheet("#SplashLoadingScreen { border-image: url(:/images/loading_03.jpeg); }");
        }

        // MENSAGENS DE STATUS
        if(i == 10) {
            ui  -> labelTextSplashStatus   -> setText("Procurando a aceleração da gravidade...");
        }
        else if(i == 25) {
            ui  -> labelTextSplashStatus   -> setText("Torcendo para o Arduíno não desconectar...");
        }
        else if(i == 40) {
            ui  -> labelTextSplashStatus   -> setText("Ajustando o atrito da pista...");
        }
        else if(i == 50) {
            ui  -> labelTextSplashStatus   -> setText("Polindo as rodinhas do carrinho...");
        }
        else if(i == 70) {
            ui  -> labelTextSplashStatus   -> setText("Consultando Isaac Newton...");
        }
        else if(i == 90) {
            ui  -> labelTextSplashStatus   -> setText("Forçando os dados a baterem...");
        }

        // Força o Qt a redesenhar a tela e manter a animação do GIF
        QCoreApplication::processEvents();

        // Tempo de pausa da iteração
        int tempo;
        if (i == 30 || i == 60 || i == 90) {
            tempo = QRandomGenerator::global()   ->  bounded(700, 1200);    // Arquivo pesado
        }
        else {
            tempo = QRandomGenerator::global()   ->  bounded(60, 120);      // Avanço fluido
        }

        QThread::msleep(tempo);
    }

    // Mensagem final
    ui  -> labelTextSplashStatus    -> setText("Tudo certo :)");
    QCoreApplication::processEvents();
    QThread::msleep(2000);  // Aguarda 2 segundos antes de fechar

    accept();
}
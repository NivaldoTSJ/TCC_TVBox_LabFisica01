#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QChart>
#include <QLineSeries>
#include <QScatterSeries>
#include <QValueAxis>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QFile>
#include <QTextStream>
#include <cmath>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:

    void on_pushButtonMainClose_clicked();

    void on_pushButtonMainStart_clicked();

    void on_pushButtonAboutUs_triggered();

    void on_pushButtonInstructions_triggered();

    void on_pushButtonSincReturn_clicked();

    void on_pushButtonSincLoadPorts_clicked();

    void on_pushButtonSincTest_clicked();

    void on_pushButtonExpClose_clicked();

    void on_pushButtonExpBeginGathering_clicked();

    void on_pushButtonSincExperiment_clicked();

    void on_pushButtonExpEquationPosition_clicked();

    void on_pushButtonExpEquationSpeed_clicked();

    void on_pushButtonExpEquationAcceleration_clicked();

    void on_pushButtonSincOffset_clicked();

    void on_pushButtonOffsetStart_clicked();

    void on_pushButtonOffsetExperimentMode_clicked();

    void on_pushButtonOffsetClose_clicked();

    void on_pushButtonExpGetTable_clicked();

    void on_horizontalSliderExpGetData_valueChanged(int value);

    void on_toolButtonSelec00_MRUV_clicked();

    void on_pushButtonSelecReturn_clicked();

    void on_pushButtonOffsetReturn_clicked();

    void on_pushButtonSimuReturn_clicked();

    void on_pushButtonSimuSave_clicked();

    void on_checkBoxExpSimu_toggled(bool checked);

    void on_pushButtonExpSimu_clicked();

    void on_checkBoxExpAvarage_toggled(bool checked);

private:
    Ui::MainWindow *ui;

    // COMUNICAÇÃO SERIAL
    QSerialPort *arduino;

    double timeZero = 0;

    // DADOS EXPERIMENTAIS
    QVector<double> dataTime;
    QVector<double> dataPosition;
    QVector<double> dataSpeed;
    QVector<double> dataAcceleration;
    double A = 0.0;
    double B = 0.0;
    double C = 0.0;

    // DADOS DE SIMULAÇÃO
    QVector<double> simuTime;
    QVector<double> simuPosition;
    QVector<double> simuSpeed;
    QVector<double> simuAcceleration;
    double simuA = 0.0;
    double simuB = 0.0;
    double simuC = 0.0;

    // FILTRO DE MÉDIA MÓVEL
    QVector<double> filteredPosition;
    QVector<double> filteredSpeed;
    QVector<double> filteredAcceleration;

    // GRÁFICOS
    QLineSeries     *zeroLineSeries;    // Linha zero
    QScatterSeries  *dataBrute;         // Dados experimentais
    QLineSeries     *dataRefined;       // Regressão quadrática
    QLineSeries     *dataSimu;          // Simulação
    QLineSeries     *dataFiltered;      // Média móvel

    QValueAxis      *eixoX;             // Tempo
    QValueAxis      *eixoY;             // Posição, velocidade ou aceleração

    // CALIBRAÇÃO E EXPORTAÇÃO
    int offsetS1 = 0;
    int offsetS2 = 0;

    int dataPercentage = 50;

    // FUNÇÕES AUXILIARES
    // Comunicação com Arduino
    bool syncArduino(const QString &portName);
    bool startExperiment();
    void readSerialData();

    // Calibração
    bool calibrateSensors();
    void saveOffset(int offsetS1temp, int offsetS2temp);
    void loadOffset();

    // Processamento dos dados
    void getFunction();
    void calculateMovingAverage();
    void calculateSimulation(int mode, double pulleyMass, double accelerationInput, double speedInput);

    // Gráficos e exportação
    void updateGraph(int mode);
    void exportCSV(const QString &path, bool exportSimu, bool exportFiltered);
};
#endif // MAINWINDOW_H

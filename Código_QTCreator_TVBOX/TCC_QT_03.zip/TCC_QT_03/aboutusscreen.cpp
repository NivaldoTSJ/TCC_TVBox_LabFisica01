#include "aboutusscreen.h"
#include "ui_aboutusscreen.h"

AboutUsScreen::AboutUsScreen(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AboutUsScreen)
{
    ui->setupUi(this);

    setWindowTitle("Sobre Nós");

    setWindowFlags(Qt::Dialog | Qt::WindowCloseButtonHint);

    connect(ui -> pushButtonAboutClose, &QPushButton::clicked, this, &QDialog::accept);
}

AboutUsScreen::~AboutUsScreen()
{
    delete ui;
}

void AboutUsScreen::on_pushButtonAboutClose_clicked()
{
    close();
}


#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "aboutusscreen.h"
#include "instructionsscreen.h"
#include <QLineSeries>
#include <QChart>
#include <QThread>
#include <qscatterseries.h>
#include <qvalueaxis.h>
#include <cmath>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QWidget>

//=====================================================================
// SETUP
//=====================================================================

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    // CONFIGURAÇÃO INICIAL DA INTERFACE
    ui  -> setupUi(this);
    setWindowTitle("Sistema de Monitoramento para Experimentos de Física");

    // LOGO DO IFSC
    QWidget *logoContainer  = new QWidget(this);
    QHBoxLayout *logoLayout = new QHBoxLayout(logoContainer);

    QLabel *logoIFSC        = new QLabel(logoContainer);
    QPixmap logo(":/images/IFSC_logo_horizontal.png");
    QPixmap logoReduzida    = logo.scaledToHeight(22, Qt::SmoothTransformation);

    logoIFSC        -> setPixmap(logoReduzida);
    logoIFSC        -> setFixedSize(logoReduzida.size());
    logoIFSC        -> setAlignment(Qt::AlignCenter);

    logoLayout      -> setContentsMargins(4, 4, 4, 4);
    logoLayout      -> setSpacing(0);
    logoLayout      -> addWidget(logoIFSC);

    logoContainer   -> setStyleSheet("background-color: #368032;");
    logoContainer   -> setFixedSize(logoReduzida.width() + 8, logoReduzida.height() + 8);

    ui  -> menubar  -> setCornerWidget(logoContainer, Qt::TopRightCorner);

    // COMUNICAÇÃO SERIAL
    arduino = new QSerialPort(this);

    // CONFIGURAÇÃO DAS SÉRIES DO GRÁFICO
    // Linha zero
    zeroLineSeries  = new QLineSeries();
    QPen zeroPen(QColor(180, 180, 180));
    zeroPen.setWidthF(1.0);
    zeroPen.setStyle(Qt::DashLine);
    zeroLineSeries  -> setPen(zeroPen);
    zeroLineSeries  -> append(0.0, 0.0);
    zeroLineSeries  -> append(2.5, 0.0);

    // Dados experimentais
    dataBrute       = new QScatterSeries();
    dataBrute       -> setName("Leituras Serial");
    dataBrute       -> setMarkerShape(QScatterSeries::MarkerShapeRotatedRectangle);
    dataBrute       -> setMarkerSize(10.0);
    dataBrute       -> setColor(Qt::blue);

    // Regressão quadrática
    dataRefined     = new QLineSeries();
    dataRefined     -> setPointsVisible(false);
    QPen penAdjust(Qt::red);
    penAdjust.setWidthF(2.5);
    dataRefined     -> setPen(penAdjust);

    // Simulação
    dataSimu        = new QLineSeries();
    dataSimu        -> setPointsVisible(false);
    QPen penSimu(Qt::green);
    penSimu.setWidthF(2.5);
    dataSimu        -> setPen(penSimu);
    dataSimu        -> setVisible(false);

    // Filtro de média móvel
    dataFiltered    = new QLineSeries();
    dataFiltered    -> setPointsVisible(true);
    QPen penFiltered(QColorConstants::Svg::orange);
    penFiltered.setWidthF(2.5);
    dataFiltered    -> setPen(penFiltered);
    dataFiltered    -> setVisible(false);

    // CONFIGURAÇÃO DOS EIXOS
    eixoX = new QValueAxis();
    eixoY = new QValueAxis();

    eixoX   -> setRange(0, 2.5);
    eixoY   -> setRange(0, 1.2);

    // CONFIGURAÇÃO DO GRÁFICO
    auto chart = new QChart();

    // Adiciona as séries
    chart   -> addSeries(zeroLineSeries);
    chart   -> addSeries(dataBrute);
    chart   -> addSeries(dataRefined);
    chart   -> addSeries(dataSimu);
    chart   -> addSeries(dataFiltered);

    // Adiciona os eixos
    chart   -> addAxis(eixoX, Qt::AlignBottom);
    chart   -> addAxis(eixoY, Qt::AlignLeft);

    // Vincula as séries aos eixos
    zeroLineSeries  -> attachAxis(eixoX);
    zeroLineSeries  -> attachAxis(eixoY);
    dataBrute       -> attachAxis(eixoX);
    dataBrute       -> attachAxis(eixoY);
    dataRefined     -> attachAxis(eixoX);
    dataRefined     -> attachAxis(eixoY);
    dataSimu        -> attachAxis(eixoX);
    dataSimu        -> attachAxis(eixoY);
    dataFiltered    -> attachAxis(eixoX);
    dataFiltered    -> attachAxis(eixoY);

    // Configuração visual do gráfico
    chart   -> legend()     -> hide();
    ui      -> chartExpData -> setChart(chart);
    ui      -> chartExpData -> setRenderHint(QPainter::Antialiasing);

    // Carrega os offsets salvos
    loadOffset();

    // Define a tela inicial
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page00_Main);

    // BLOQUEIO DE BOTÕES
    // Sincronização
    ui  -> pushButtonSincTest                   -> setEnabled(false);
    ui  -> pushButtonSincExperiment             -> setEnabled(false);
    ui  -> pushButtonSincOffset                 -> setEnabled(false);

    // Experimento
    ui  -> pushButtonExpBeginGathering          -> setEnabled(false);
    ui  -> pushButtonExpEquationPosition        -> setEnabled(false);
    ui  -> pushButtonExpEquationSpeed           -> setEnabled(false);
    ui  -> pushButtonExpEquationAcceleration    -> setEnabled(false);
    ui  -> pushButtonExpGetTable                -> setEnabled(false);

    // Opções de visualização
    ui  -> checkBoxExpSimu                      -> setEnabled(false);
    ui  -> checkBoxExpAvarage                   -> setEnabled(false);
}

MainWindow::~MainWindow()
{
    if((arduino) && (arduino -> isOpen())) {                            // Se o arduino estiver aberto ao fechar, encerra a comunicação
        arduino -> close();
    }
    delete ui;                                                          // Apaga o objeto da tela
}


//=====================================================================
// TELA INICIAL
//=====================================================================

void MainWindow::on_pushButtonMainClose_clicked()                       // Botão da Tela Inicial de fechar
{
    close();
}

void MainWindow::on_pushButtonMainStart_clicked()                       // Botão da Tela Inicial de continuar para a sincronização
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page01_ExperimentSelection);
}

void MainWindow::on_pushButtonAboutUs_triggered()
{
    AboutUsScreen dialog(this);
    dialog.exec();
}

void MainWindow::on_pushButtonInstructions_triggered()
{
    instructionsScreen dialog(this);
    dialog.exec();
}


//=====================================================================
// TELA DE SELEÇÃO
//=====================================================================

void MainWindow::on_toolButtonSelec00_MRUV_clicked()
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page02_ArduinoSinc);
}

void MainWindow::on_pushButtonSelecReturn_clicked()
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page00_Main);
}


//=====================================================================
// TELA DE SINCRONIZAÇÃO
//=====================================================================

void MainWindow::on_pushButtonSincReturn_clicked()                  // Botão da Tela de Sincronização de Voltar
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page01_ExperimentSelection);
}

void MainWindow::on_pushButtonSincLoadPorts_clicked()
{
    // Limpa a lista
    ui  -> comboBoxSincPorts    -> clear();

    // Obtém lista
    const QList<QSerialPortInfo> portas = QSerialPortInfo::availablePorts();

    // Inclui apenas portas USB seriais
    for(const QSerialPortInfo &porta : portas) {
        QString nome = porta.portName();

        if(nome.startsWith("ttyUSB") || nome.startsWith("ttyACM") || nome.startsWith("COM")) {
            ui  -> comboBoxSincPorts    -> addItem(nome);
        }
    }

    // Verifica se encontrou alguma porta válida
    if(ui   -> comboBoxSincPorts    -> count() == 0) {
        ui  -> comboBoxSincPorts    -> addItem("Nenhuma porta encontrada");
        ui  -> pushButtonSincTest   -> setEnabled(false);
        return;
    }

    // Libera o botão de sincronização
    ui  -> pushButtonSincTest   -> setEnabled(true);
}

void MainWindow::on_pushButtonSincTest_clicked()
{
    // Bloqueia os botões durante a sincronização
    ui  -> pushButtonSincExperiment     -> setEnabled(false);
    ui  -> pushButtonSincOffset         -> setEnabled(false);
    ui  -> pushButtonExpBeginGathering  -> setEnabled(false);

    // Sincroniza o Arduino e os sensores
    QString portName = ui   -> comboBoxSincPorts    -> currentText();
    bool synchronized = syncArduino(portName);

    // Libera os botões se a sincronização foi concluída
    ui  -> pushButtonSincExperiment     -> setEnabled(synchronized);
    ui  -> pushButtonSincOffset         -> setEnabled(synchronized);
    ui  -> pushButtonExpBeginGathering  -> setEnabled(synchronized);
}

void MainWindow::on_pushButtonSincExperiment_clicked()              // Botão da Tela de Sincronização de ir para o experimento
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page04_Experiment);
}

void MainWindow::on_pushButtonSincOffset_clicked()                  // Botão da Tela de Sincronização de ir para a Calibração
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page03_Offset);

}


//=====================================================================
// TELA DE CALIBRAÇÃO
//=====================================================================

void MainWindow::on_pushButtonOffsetStart_clicked()
{
    ui  -> pushButtonOffsetStart            -> setEnabled(false);
    ui  -> pushButtonOffsetExperimentMode   -> setEnabled(false);
    ui  -> pushButtonOffsetReturn           -> setEnabled(false);

    ui  -> labelTextOffsetStatus    -> setText("Calibrando");
    QCoreApplication::processEvents();

    // Executa a calibração
    bool calibrated = calibrateSensors();

    if(calibrated) {
        ui  -> labelTextOffsetS1Value   -> setText(QString::asprintf("%d mm", offsetS1));
        ui  -> labelTextOffsetS2Value   -> setText(QString::asprintf("%d mm", offsetS2));
        ui  -> labelTextOffsetStatus    -> setText("Calibrado");
    }
    else {
        ui  -> labelTextOffsetStatus    -> setText("Erro");
    }

    ui  -> pushButtonOffsetStart            -> setEnabled(true);
    ui  -> pushButtonOffsetExperimentMode   -> setEnabled(true);
    ui  -> pushButtonOffsetReturn           -> setEnabled(true);

    QCoreApplication::processEvents();
}

void MainWindow::on_pushButtonOffsetExperimentMode_clicked()        // Botão da Tela de Calibração de ir para Experimento
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page04_Experiment);
}

void MainWindow::on_pushButtonOffsetReturn_clicked()
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page02_ArduinoSinc);

    loadOffset();
}

void MainWindow::on_pushButtonOffsetClose_clicked()                 // Botão da Calibração de fechar
{
    close();
}


//=====================================================================
// TELA DE EXPERIMENTO
//=====================================================================

void MainWindow::on_pushButtonExpClose_clicked()                    // Botão da Tela de Experimento de Sair
{
    close();
}

void MainWindow::on_pushButtonExpBeginGathering_clicked()
{
    // Bloqueia os controles durante a coleta
    ui  -> pushButtonExpBeginGathering          -> setEnabled(false);
    ui  -> pushButtonExpEquationPosition        -> setEnabled(false);
    ui  -> pushButtonExpEquationSpeed           -> setEnabled(false);
    ui  -> pushButtonExpEquationAcceleration    -> setEnabled(false);
    ui  -> pushButtonExpGetTable                -> setEnabled(false);
    ui  -> pushButtonExpSimu                    -> setEnabled(false);
    ui  -> pushButtonAboutUs                    -> setEnabled(false);
    ui  -> pushButtonInstructions               -> setEnabled(false);
    ui  -> checkBoxExpAvarage                   -> setEnabled(false);
    ui  -> checkBoxExpAvarage                   -> setChecked(false);
    ui  -> checkBoxExpSimu                      -> setEnabled(false);

    // Inicia a coleta de dados
    bool started = startExperiment();

    if(!started) {
        ui  -> pushButtonExpBeginGathering  -> setEnabled(true);
        ui  -> pushButtonExpSimu            -> setEnabled(true);
        ui  -> pushButtonAboutUs            -> setEnabled(true);
        ui  -> pushButtonInstructions       -> setEnabled(true);
        ui  -> checkBoxExpSimu              -> setEnabled(!simuPosition.isEmpty());
    }
}

void MainWindow::on_pushButtonExpEquationPosition_clicked()
{
    updateGraph(0);
}

void MainWindow::on_pushButtonExpEquationSpeed_clicked()
{
    updateGraph(1);
}

void MainWindow::on_pushButtonExpEquationAcceleration_clicked()
{
    updateGraph(2);
}

void MainWindow::on_pushButtonExpGetTable_clicked()
{
    // Cria arquivo no local desejado
    QString path = QFileDialog::getSaveFileName(this, "Salvar Tabela do Experimento", "dados_experimento.csv", "Arquivos CSV (*.csv);;Todos os Arquivos (*)");

    if (path.isEmpty()) {
        return;
    }

    bool exportSimu     = ui    -> checkBoxExpSimu      -> isChecked();
    bool exportFiltered = ui    -> checkBoxExpAvarage   -> isChecked();

    exportCSV(path, exportSimu, exportFiltered);
}

void MainWindow::on_horizontalSliderExpGetData_valueChanged(int value)
{
    ui  -> labelTextExpGetTable     -> setText(QString::asprintf("Exportar tabela com %d%% dos %d dados:", value, dataTime.size()));
    dataPercentage = value;
}

void MainWindow::on_checkBoxExpSimu_toggled(bool checked)
{
    dataSimu        -> setVisible(checked);
}

void MainWindow::on_pushButtonExpSimu_clicked()
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page05_SImu);
}

void MainWindow::on_checkBoxExpAvarage_toggled(bool checked)
{
    dataFiltered    -> setVisible(checked);
}


//=====================================================================
//  TELA SIMULAÇÃO
//=====================================================================

void MainWindow::on_pushButtonSimuReturn_clicked()
{
    ui  -> stackedWidget    -> setCurrentWidget(ui  -> page04_Experiment);
}

void MainWindow::on_pushButtonSimuSave_clicked()
{
    // Seleção do modo de simulação
    int mode = ui   -> comboBoxSimuMode     -> currentIndex();

    // Parâmetros físicos
    double pulleyMass           = ui    -> doubleSpinBoxSimuValueMass   -> value();
    double accelerationInput    = ui    -> doubleSpinBoxSimuValueAcel   -> value();
    double speedInput           = ui    -> doubleSpinBoxSimuValueSpeed  -> value();

    // Calcula a simulação
    calculateSimulation(mode, pulleyMass, accelerationInput, speedInput);

    // Exibição das equações
    ui  -> labelTextSimuEquationPosition     -> setText(QString::asprintf("%.3f t² + %.3f t + %.3f", simuA, simuB, simuC));
    ui  -> labelTextSimuEquationSpeed        -> setText(QString::asprintf("%.3f t + %.3f", (2*simuA), simuB));
    ui  -> labelTextSimuEquationAcceleration -> setText(QString::asprintf("%.3f", (2*simuA)));

    // Libera a visualização da simulação
    ui  -> checkBoxExpSimu  -> setEnabled(!simuPosition.isEmpty());

    // Reinicia a visualização do gráfico para posição
    dataBrute       -> clear();
    dataRefined     -> clear();
    dataFiltered    -> clear();

    eixoY   -> setRange(0, 1.2);
}